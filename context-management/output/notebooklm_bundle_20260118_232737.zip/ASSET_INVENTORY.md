# Asset Inventory: The Automations

> "If it automates the project, it is listed here."

## 1. The Active Command Center (context-management)
*These are the tools you should use daily to operate the Alien Architecture.*

### The Intelligence (AI)
| Tool | Command | Description |
| :--- | :--- | :--- |
| **The Surgeon** | `python context-management/tools/ai/analyze.py --mode forensic` | **Forensic Analysis**. Provides verifiable facts with line-number citations. |
| **The Architect** | `python context-management/tools/ai/analyze.py --mode architect` | **Global Reasoning**. Analyzes code against the `COLLIDER_ARCHITECTURE` theory. |
| **The Librarian** | *(Browser Interface)* | **vertex-ai-agent-builder**. Instant search and Q&A over the entire repo. |
| **RAG Setup** | `python context-management/tools/ai/setup_rag.py` | **Infrastructure**. Automates RAG setup and NotebookLM bundling. |

### The Machinery (Mirror & Maintenance)
| Tool | Command | Description |
| :--- | :--- | :--- |
| **The Mirror** | `python context-management/tools/archive/archive.py mirror` | **Cloud Sync**. Mirrors the repo to `gs://elements-archive-2026` for AI access. |
| **Timestamp Tracker** | `python context-management/tools/maintenance/timestamps.py` | **Auditing**. Updates `project_elements_file_timestamps.csv` for drift detection. |
| **Stale Archiver** | `python context-management/tools/maintenance/archive_stale.py` | **Cleanup**. Auto-moves old files to `archive/zombie_code`. |
| **Bootstrapper** | `bash context-management/tools/maintenance/boot.sh` | **Setup**. Initializes the environment (legacy). |

---

## 2. The Legacy Archive (Code Graveyard)
*These scripts are in `archive/`. They are NOT active, but contain valuable logic you might want to resurrect.*

### Implementation Scripts (`archive/scripts/`)
*   `analyze_structure.py`: Old structural analysis logic.
*   `analyze_theory.py`: Logic for parsing the old theory files.
*   `batch_analysis_runner.py`: Old bulk processing script.
*   `code_smell_validator.py`: Early linter experiments.
*   `constraints_calculator.py`: Logic for "Physical Constraints" theory.
*   `1440_csv_generator.py`: Old timestamp generator.

### Orphaned Tools (`archive/orphaned_tools_2025/`)
*   `archive_assets.py`
*   `scan_repo_truth_sources.py`
*   `validate_subhadron_dataset.py`

*(Note: There are ~50 more scripts in these folders. Use "The Librarian" (Agent Builder) to search inside them if you need to find "that old logic that checked for circular dependencies".)*
