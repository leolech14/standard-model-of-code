import React, { useState, Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { OrbitControls } from '@react-three/drei';
import { Leva, useControls, button } from 'leva';
import { Sidebar } from './Sidebar';
import { HolonStack } from './HolonStack';
import { DraggableCard } from './DraggableCard';
import { useIsMobile } from '../hooks/use-mobile';
import { ENTITIES, CONCORDANCES, Entity, Concordance } from '../data/smocData';

import { cn } from '../lib/utils';

export function SmocScene() {
  const isMobile = useIsMobile();
  const [activeLevelId, setActiveLevelId] = useState<number>(7); // Default L7 SYSTEM
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(!isMobile);
  const [entities, setEntities] = useState<Entity[]>(ENTITIES);
  const [concordances, setConcordances] = useState<Concordance[]>(CONCORDANCES);
  const [orbitEnabled, setOrbitEnabled] = useState(true);
  const controlsRef = useRef<any>(null);

  // Update sidebar state when mobile status changes
  React.useEffect(() => {
    setIsSidebarOpen(!isMobile);
  }, [isMobile]);

  const { showDriftVectors, showAxioms, darkMode } = useControls({
    showDriftVectors: { value: true, label: 'Show Drift Vectors' },
    showAxioms: { value: true, label: 'Show Axioms' },
    darkMode: { value: false, label: 'Dark Mode' },
    'Export Image': button(() => {
      const canvas = document.getElementById('smoc-canvas') as HTMLCanvasElement;
      if (canvas) {
        const link = document.createElement('a');
        link.download = 'smoc-explorer.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
      }
    }),
  });

  const handleSelectLevel = (id: number) => {
    setActiveLevelId(id);
    if (isMobile) setIsSidebarOpen(false);
  };

  const handleMerge = (sourceId: string, targetId: string) => {
    setEntities(prev => {
      const source = prev.find(e => e.id === sourceId);
      const target = prev.find(e => e.id === targetId);
      if (!source || !target) return prev;

      // Create merged entity
      const merged: Entity = {
        ...target,
        name: `${target.name} + ${source.name}`,
        role: 'Composite',
        description: `Merged: ${target.description || ''} | ${source.description || ''}`,
      };

      return prev.map(e => e.id === targetId ? merged : e).filter(e => e.id !== sourceId);
    });

    setConcordances(prev => {
      // Update concordances to point to targetId instead of sourceId
      return prev.map(c => {
        if (c.source === sourceId) return { ...c, source: targetId };
        if (c.target === sourceId) return { ...c, target: targetId };
        return c;
      });
    });

    if (selectedEntityId === sourceId) {
      setSelectedEntityId(targetId);
    }
  };

  const handleUpdateEntityPosition = (id: string, x: number, y: number) => {
    setEntities(prev => prev.map(e => e.id === id ? { ...e, x, y } : e));
  };

  return (
    <div className={cn(
      "flex h-screen w-full overflow-hidden font-serif selection:bg-black selection:text-white transition-colors duration-300",
      darkMode ? "bg-black text-white dark" : "bg-white text-black"
    )}>
      <Sidebar
        activeLevelId={activeLevelId}
        onSelectLevel={handleSelectLevel}
        isOpen={isSidebarOpen}
        setIsOpen={setIsSidebarOpen}
        darkMode={darkMode}
        onSelectEntity={setSelectedEntityId}
        entities={entities}
      />

      <main className={cn(
        "flex-1 relative transition-all duration-300 ease-in-out h-full",
        isSidebarOpen ? "ml-80" : "ml-0"
      )}>
        <div className="absolute inset-0 z-0 w-full h-full">
          <Canvas id="smoc-canvas" camera={{ position: [20, 10, 20], fov: 35 }} shadows gl={{ preserveDrawingBuffer: true }} style={{ width: '100%', height: '100%' }}>
            <color attach="background" args={[darkMode ? '#000000' : '#ffffff']} />
            <ambientLight intensity={darkMode ? 0.4 : 0.9} />
            <directionalLight position={[10, 20, 10]} intensity={darkMode ? 1.0 : 1.5} castShadow />
            <directionalLight position={[-10, -20, -10]} intensity={darkMode ? 0.3 : 0.5} />
            
            <Suspense fallback={
              <mesh position={[0, 17.5, 0]}>
                <boxGeometry args={[5, 5, 5]} />
                <meshStandardMaterial color="red" />
              </mesh>
            }>
              <HolonStack
                activeLevelId={activeLevelId}
                showDriftVectors={showDriftVectors}
                selectedEntityId={selectedEntityId}
                onSelectEntity={setSelectedEntityId}
                darkMode={darkMode}
                entities={entities}
                concordances={concordances}
                onMerge={handleMerge}
                onUpdatePosition={handleUpdateEntityPosition}
                setOrbitEnabled={setOrbitEnabled}
              />
            </Suspense>

            <OrbitControls
              ref={controlsRef}
              target={[0, activeLevelId * 2.5, 0]}
              enableDamping
              dampingFactor={0.05}
              minDistance={5}
              maxDistance={50}
              enabled={orbitEnabled}
            />
          </Canvas>
        </div>

        <div className="absolute top-4 right-4 z-50 hidden md:block">
          <Leva
            theme={{
              colors: {
                elevation1: darkMode ? 'rgba(0,0,0,0.8)' : 'rgba(255,255,255,0.8)',
                elevation2: darkMode ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)',
                elevation3: darkMode ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
                accent1: darkMode ? '#ffffff' : '#000000',
                accent2: darkMode ? '#ffffff' : '#000000',
                accent3: darkMode ? '#ffffff' : '#000000',
                highlight1: darkMode ? '#ffffff' : '#000000',
                highlight2: darkMode ? '#ffffff' : '#000000',
                highlight3: darkMode ? '#ffffff' : '#000000',
                vivid1: darkMode ? '#ffffff' : '#000000',
                folderWidgetColor: darkMode ? '#ffffff' : '#000000',
                folderTextColor: darkMode ? '#ffffff' : '#000000',
                toolTipBackground: darkMode ? '#ffffff' : '#000000',
                toolTipText: darkMode ? '#000000' : '#ffffff',
              },
              radii: {
                xs: '0',
                sm: '0',
                lg: '0',
              },
              space: {
                sm: '6px',
                md: '10px',
                rowGap: '7px',
                colGap: '7px',
              },
              fonts: {
                mono: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
                sans: 'ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif',
              },
              shadows: {
                level1: 'none',
                level2: 'none',
              },
              borderWidths: {
                root: '0px',
                input: '1px',
                focus: '1px',
                hover: '1px',
                active: '1px',
                folder: '1px',
              },
            }}
            titleBar={{ title: 'PARAMETERS' }}
          />
        </div>

        <DraggableCard
          activeLevelId={activeLevelId}
          showAxioms={showAxioms}
          selectedEntityId={selectedEntityId}
          onCloseEntity={() => setSelectedEntityId(null)}
          darkMode={darkMode}
          entities={entities}
        />
      </main>
    </div>
  );
}
