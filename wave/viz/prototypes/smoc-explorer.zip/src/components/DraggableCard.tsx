import React, { useState, useRef, useEffect } from 'react';
import { motion, useDragControls } from 'framer-motion';
import { Maximize2, Minimize2, GripHorizontal, X, AlertTriangle } from 'lucide-react';
import { LEVELS, Entity } from '../data/smocData';
import { cn } from '../lib/utils';

interface DraggableCardProps {
  activeLevelId: number;
  showAxioms: boolean;
  selectedEntityId: string | null;
  onCloseEntity: () => void;
  darkMode: boolean;
  entities: Entity[];
}

export function DraggableCard({ activeLevelId, showAxioms, selectedEntityId, onCloseEntity, darkMode, entities }: DraggableCardProps) {
  const level = LEVELS.find((l) => l.id === activeLevelId);
  const selectedEntity = entities.find((e) => e.id === selectedEntityId);
  const [isMinimized, setIsMinimized] = useState(false);
  const [size, setSize] = useState({ width: 320, height: 450 });
  const dragControls = useDragControls();
  const cardRef = useRef<HTMLDivElement>(null);

  if (!level) return null;

  const handleResize = (e: React.MouseEvent | MouseEvent) => {
    e.preventDefault();
    const startX = e.clientX;
    const startY = e.clientY;
    const startWidth = size.width;
    const startHeight = size.height;

    const onMouseMove = (moveEvent: MouseEvent) => {
      setSize({
        width: Math.max(250, startWidth + moveEvent.clientX - startX),
        height: Math.max(200, startHeight + moveEvent.clientY - startY),
      });
    };

    const onMouseUp = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  };

  return (
    <motion.div
      ref={cardRef}
      drag
      dragControls={dragControls}
      dragListener={false}
      dragMomentum={false}
      initial={{ x: 20, y: window.innerHeight - 470 }}
      style={{
        width: isMinimized ? 320 : size.width,
        height: isMinimized ? 'auto' : size.height,
        minWidth: 280,
        minHeight: isMinimized ? 'auto' : 200,
      }}
      className={cn(
        "fixed z-50 flex flex-col overflow-hidden backdrop-blur-md",
        darkMode 
          ? "bg-black/80 text-white border border-white/20" 
          : "bg-white/80 text-black border border-black/20"
      )}
    >
      {/* Header / Drag Handle */}
      <div
        className="px-4 py-3 flex items-center justify-between cursor-grab active:cursor-grabbing select-none border-b border-inherit"
        onPointerDown={(e) => dragControls.start(e)}
      >
        <div className="flex items-center gap-3">
          <span className="font-mono text-[10px] tracking-widest opacity-50">
            {selectedEntity ? `[ ENTITY ]` : `[ LEVEL ]`}
          </span>
          <span className="font-serif text-xs italic">
            {selectedEntity ? selectedEntity.name : `L${level.id} ${level.zone}`}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {selectedEntity && (
            <button
              onClick={onCloseEntity}
              className="opacity-50 hover:opacity-100 transition-opacity"
            >
              <X size={12} strokeWidth={1} />
            </button>
          )}
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="opacity-50 hover:opacity-100 transition-opacity"
          >
            {isMinimized ? <Maximize2 size={12} strokeWidth={1} /> : <Minimize2 size={12} strokeWidth={1} />}
          </button>
        </div>
      </div>

      {/* Content */}
      {!isMinimized && (
        <div className="flex-1 p-6 flex flex-col gap-8 overflow-y-auto custom-scrollbar relative">
          {selectedEntity ? (
            <>
              <div>
                <h2 className="font-serif text-2xl tracking-tight leading-none mb-3 break-all">{selectedEntity.name}</h2>
                <div className="flex gap-4 font-mono text-[10px] opacity-60 uppercase tracking-widest">
                  <span>type: {selectedEntity.type}</span>
                  {selectedEntity.role && (
                    <span>role: {selectedEntity.role}</span>
                  )}
                  <span>pos: [{selectedEntity.x ?? (selectedEntity.type === 'CODE' ? -4 : 4)}, {selectedEntity.level * 2.5}, {selectedEntity.y ?? 0}]</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 border-t border-b border-inherit py-4">
                <div>
                  <p className="font-mono text-[9px] opacity-50 uppercase tracking-widest mb-1">Level</p>
                  <p className="font-mono text-xs">L{selectedEntity.level}</p>
                </div>
                <div>
                  <p className="font-mono text-[9px] opacity-50 uppercase tracking-widest mb-1">Status</p>
                  <p className={cn("font-mono text-xs", selectedEntity.antimatter ? "text-red-500" : "")}>
                    {selectedEntity.antimatter ? "VIOLATION" : "NOMINAL"}
                  </p>
                </div>
              </div>
              
              {selectedEntity.antimatter && (
                <div className="border border-red-500/30 p-4 flex gap-4 text-red-500">
                  <AlertTriangle size={14} className="shrink-0 mt-0.5" strokeWidth={1} />
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-widest mb-2">Antimatter Detected</p>
                    <p className="font-serif text-xs italic">{selectedEntity.antimatter}</p>
                  </div>
                </div>
              )}

              {selectedEntity.description && (
                <div>
                  <p className="font-mono text-[9px] opacity-50 uppercase tracking-widest mb-2">Description</p>
                  <p className="font-serif text-sm leading-relaxed opacity-80">
                    {selectedEntity.description}
                  </p>
                </div>
              )}
            </>
          ) : (
            <>
              <div>
                <h2 className="font-serif text-2xl tracking-tight leading-none mb-4">{level.name}</h2>
                <p className="font-serif text-sm leading-relaxed opacity-80">
                  {level.description}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 border-t border-b border-inherit py-4">
                <div>
                  <p className="font-mono text-[9px] opacity-50 uppercase tracking-widest mb-1">Concordance</p>
                  <p className="font-mono text-xs">0.95 &sigma;</p>
                </div>
                <div>
                  <p className="font-mono text-[9px] opacity-50 uppercase tracking-widest mb-1">Entropy</p>
                  <p className="font-mono text-xs">1.24 J/K</p>
                </div>
                <div>
                  <p className="font-mono text-[9px] opacity-50 uppercase tracking-widest mb-1">Y-Axis</p>
                  <p className="font-mono text-xs">{level.id * 2.5}u</p>
                </div>
                <div>
                  <p className="font-mono text-[9px] opacity-50 uppercase tracking-widest mb-1">Entities</p>
                  <p className="font-mono text-xs">{entities.filter(e => e.level === level.id).length}</p>
                </div>
              </div>

              {showAxioms && (
                <div className="mt-auto pt-4">
                  <p className="font-mono text-[9px] opacity-50 uppercase tracking-widest mb-4">Eq. {level.id}.1</p>
                  <div className="font-serif italic text-base text-center px-4 opacity-90">
                    {level.axiom}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* Resize Handle */}
      {!isMinimized && (
        <div
          className={cn(
            "absolute bottom-0 right-0 w-4 h-4 cursor-se-resize z-10",
            darkMode ? "bg-white/20 hover:bg-white/40" : "bg-black/10 hover:bg-black/20"
          )}
          onMouseDown={handleResize}
        />
      )}
    </motion.div>
  );
}
