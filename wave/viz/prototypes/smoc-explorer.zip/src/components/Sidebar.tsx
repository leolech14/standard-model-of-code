import React, { useState } from 'react';
import { LEVELS, Entity } from '../data/smocData';
import { cn } from '../lib/utils';
import { ChevronRight, Menu, Search, X } from 'lucide-react';

interface SidebarProps {
  activeLevelId: number;
  onSelectLevel: (id: number) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  darkMode: boolean;
  onSelectEntity: (id: string) => void;
  entities: Entity[];
}

export function Sidebar({ activeLevelId, onSelectLevel, isOpen, setIsOpen, darkMode, onSelectEntity, entities }: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const searchResults = searchQuery.trim() === '' 
    ? [] 
    : entities.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()) || e.role?.toLowerCase().includes(searchQuery.toLowerCase()));
  return (
    <>
      {/* Mobile overlay */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className={cn(
            "md:hidden fixed top-4 left-4 z-50 p-2 border shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]",
            darkMode ? "bg-black border-white text-white shadow-[4px_4px_0px_0px_rgba(255,255,255,1)]" : "bg-white border-black text-black"
          )}
        >
          <Menu size={24} />
        </button>
      )}

      {/* Sidebar */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-80 flex flex-col transition-transform duration-300 ease-in-out",
          isOpen ? "translate-x-0" : "-translate-x-full",
          darkMode ? "bg-black text-white" : "bg-white text-black"
        )}
      >
        <div className="p-8 pb-4 flex justify-between items-start">
          <div>
            <h1 className="font-serif text-2xl tracking-tight">SMoC</h1>
            <p className="font-mono text-[10px] tracking-[0.2em] uppercase mt-1 opacity-60">Explorer</p>
          </div>
          <button onClick={() => setIsOpen(false)} className="p-1 opacity-50 hover:opacity-100 transition-opacity">
            <ChevronRight size={16} strokeWidth={1} />
          </button>
        </div>

        <div className="px-8 py-4">
          <div className="relative">
            <span className="absolute left-0 top-1/2 -translate-y-1/2 font-mono text-[10px] opacity-50">/</span>
            <input
              type="text"
              placeholder="search_entities"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={cn(
                "w-full pl-4 pr-8 py-1 text-xs font-mono bg-transparent border-b focus:outline-none transition-colors",
                darkMode 
                  ? "border-white/20 text-white placeholder:text-white/30 focus:border-white/60" 
                  : "border-black/20 text-black placeholder:text-black/30 focus:border-black/60"
              )}
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-0 top-1/2 -translate-y-1/2 opacity-50 hover:opacity-100"
              >
                <X size={12} strokeWidth={1} />
              </button>
            )}
          </div>
          
          {searchQuery && (
            <div className="mt-4 max-h-48 overflow-y-auto custom-scrollbar">
              {searchResults.length === 0 ? (
                <p className="text-[10px] font-mono opacity-50">0 results</p>
              ) : (
                <ul className="space-y-2">
                  {searchResults.map(entity => (
                    <li key={entity.id}>
                      <button
                        onClick={() => {
                          onSelectLevel(entity.level);
                          onSelectEntity(entity.id);
                          setSearchQuery('');
                        }}
                        className="w-full text-left text-[10px] font-mono flex items-baseline justify-between group opacity-70 hover:opacity-100 transition-opacity"
                      >
                        <span className="truncate">{entity.name}</span>
                        <span className="ml-2 opacity-50">L{entity.level}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar px-8 py-4">
          <div className="space-y-8">
            {['COSMOLOGICAL', 'SYSTEMIC', 'SEMANTIC', 'SYNTACTIC', 'PHYSICAL'].map(zone => {
              const zoneLevels = LEVELS.filter(l => l.zone === zone).reverse();
              if (zoneLevels.length === 0) return null;
              
              return (
                <div key={zone} className="relative">
                  <div className="absolute -left-4 top-0 bottom-0 w-px bg-current opacity-10" />
                  <div className="text-[9px] font-mono opacity-40 uppercase tracking-widest mb-3 pl-2">
                    {zone}
                  </div>
                  <ul className="space-y-1">
                    {zoneLevels.map((level) => (
                      <li key={level.id}>
                        <button
                          onClick={() => onSelectLevel(level.id)}
                          className={cn(
                            "w-full text-left py-1.5 flex items-baseline gap-4 group transition-all duration-200",
                            activeLevelId === level.id 
                              ? "opacity-100 translate-x-2" 
                              : "opacity-40 hover:opacity-80 hover:translate-x-1"
                          )}
                        >
                          <span className="font-mono text-[10px] w-4 text-right opacity-50">
                            {activeLevelId === level.id ? "→" : ""}
                          </span>
                          <span className="font-mono text-[10px] w-4">
                            {level.id}
                          </span>
                          <span className={cn(
                            "font-serif text-sm tracking-wide",
                            activeLevelId === level.id ? "italic" : ""
                          )}>
                            {level.name.split(' ').slice(1).join(' ').toLowerCase()}
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>

        <div className="p-8 pt-4">
          <p className="font-serif text-[11px] leading-relaxed opacity-60">
            Standard Model of Code<br />
            Interactive 3D Holarchy
          </p>
          <p className="font-mono text-[9px] mt-4 opacity-40">
            {LEVELS.find(l => l.id === activeLevelId)?.citation}
          </p>
        </div>
      </div>
    </>
  );
}
