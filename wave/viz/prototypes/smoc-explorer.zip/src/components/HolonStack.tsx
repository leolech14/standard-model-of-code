import React, { useRef, useMemo, useState } from 'react';
import { useFrame, ThreeEvent } from '@react-three/fiber';
import { Text, Edges, Line } from '@react-three/drei';
import * as THREE from 'three';
import { LEVELS, Entity, Concordance } from '../data/smocData';

const LEVEL_HEIGHT = 2.5;

interface EntityNodeProps {
  entity: Entity;
  isActive: boolean;
  isSelected: boolean;
  onSelect: () => void;
  darkMode: boolean;
  setOrbitEnabled: (enabled: boolean) => void;
  onDrag: (id: string, x: number, z: number) => void;
  onDragEnd: (id: string, x: number, z: number) => void;
}

function EntityNode({ entity, isActive, isSelected, onSelect, darkMode, setOrbitEnabled, onDrag, onDragEnd }: EntityNodeProps) {
  const groupRef = useRef<THREE.Group>(null);
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  
  const isCode = entity.type === 'CODE';
  const isComposite = entity.role === 'Composite';
  const scale = isComposite ? 1.5 : 1;
  const xOffset = entity.x ?? (isCode ? -4 : 4);
  const zOffset = entity.y ?? 0;
  const yPos = entity.level * LEVEL_HEIGHT;

  // Plane for dragging (XZ plane at y = yPos)
  const dragPlane = useMemo(() => new THREE.Plane(new THREE.Vector3(0, 1, 0), -yPos), [yPos]);

  useFrame((state) => {
    if (meshRef.current && isActive && !isDragging) {
      meshRef.current.rotation.y += 0.005;
      meshRef.current.position.y = Math.sin(state.clock.elapsedTime * 2 + entity.id.charCodeAt(0)) * 0.1;
    } else if (meshRef.current && !isDragging) {
      meshRef.current.position.y = 0;
    }
  });

  const handlePointerDown = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setIsDragging(true);
    setOrbitEnabled(false);
    onSelect();
    document.body.style.cursor = 'grabbing';
    (e.target as any).setPointerCapture?.(e.pointerId);
  };

  const handlePointerMove = (e: ThreeEvent<PointerEvent>) => {
    if (isDragging && groupRef.current) {
      e.stopPropagation();
      const intersect = new THREE.Vector3();
      const result = e.ray.intersectPlane(dragPlane, intersect);
      if (result) {
        groupRef.current.position.x = intersect.x;
        groupRef.current.position.z = intersect.z;
        onDrag(entity.id, intersect.x, intersect.z); // Update global state for real-time lines
      }
    }
  };

  const handlePointerUp = (e: ThreeEvent<PointerEvent>) => {
    if (isDragging) {
      e.stopPropagation();
      setIsDragging(false);
      setOrbitEnabled(true);
      document.body.style.cursor = hovered ? 'grab' : 'auto';
      (e.target as any).releasePointerCapture?.(e.pointerId);
      if (groupRef.current) {
        onDragEnd(entity.id, groupRef.current.position.x, groupRef.current.position.z);
      }
    }
  };

  const baseColor = darkMode ? "#000000" : "#ffffff";
  const hoverColor = darkMode ? "#1a1a1a" : "#f5f5f5";
  const selectedColor = darkMode ? "#333333" : "#e5e5e5";
  
  let edgeColor = isSelected ? (darkMode ? "#ffffff" : "#000000") : (darkMode ? "#666666" : "#999999");
  if (entity.antimatter) {
    edgeColor = "#ef4444"; // Red for antimatter violations
  }
  
  const textColor = entity.antimatter ? "#ef4444" : (darkMode ? "#ffffff" : "#000000");

  return (
    <group ref={groupRef} position={[xOffset, yPos, zOffset]} scale={[scale, scale, scale]}>
      <mesh
        ref={meshRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerOut={(e) => {
          if (!isDragging) {
            setHovered(false);
            document.body.style.cursor = 'auto';
          }
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          if (!isDragging) {
            setHovered(true);
            document.body.style.cursor = 'grab';
          }
        }}
      >
        {isCode ? <boxGeometry args={[0.6, 0.6, 0.6]} /> : <sphereGeometry args={[0.4, 32, 32]} />}
        <meshStandardMaterial 
          color={isSelected ? selectedColor : (hovered ? hoverColor : baseColor)} 
          transparent={isDragging}
          opacity={isDragging ? 0.8 : 1}
        />
        <Edges scale={1.0} threshold={15} color={edgeColor} />
      </mesh>
      <Text
        position={[0, 0.8, 0]}
        fontSize={0.2}
        color={textColor}
        anchorX="center"
        anchorY="middle"
      >
        {entity.name}
      </Text>
      {entity.role && (
        <Text
          position={[0, 0.5, 0]}
          fontSize={0.15}
          color={textColor}
          anchorX="center"
          anchorY="middle"
          fontStyle="italic"
        >
          {entity.role}
        </Text>
      )}
    </group>
  );
}

function LevelPlane({ level, isActive, darkMode }: { level: typeof LEVELS[0]; isActive: boolean; darkMode: boolean }) {
  const yPos = level.id * LEVEL_HEIGHT;
  const activeColor = darkMode ? '#ffffff' : '#000000';
  const inactiveColor = darkMode ? '#333333' : '#e5e5e5';
  const textColor = isActive ? activeColor : (darkMode ? '#666666' : '#999999');

  const getZoneColor = (zone: string, isDark: boolean) => {
    switch (zone) {
      case 'PHYSICAL': return isDark ? '#050505' : '#fafafa';
      case 'SYNTACTIC': return isDark ? '#0a0a0a' : '#f5f5f5';
      case 'SEMANTIC': return isDark ? '#111111' : '#f0f0f0';
      case 'SYSTEMIC': return isDark ? '#1a1a1a' : '#ebebeb';
      case 'COSMOLOGICAL': return isDark ? '#222222' : '#e6e6e6';
      default: return isDark ? '#000000' : '#ffffff';
    }
  };

  const zoneColor = getZoneColor(level.zone, darkMode);

  return (
    <group position={[0, yPos, 0]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]}>
        <planeGeometry args={[16, 16]} />
        <meshBasicMaterial color={zoneColor} transparent opacity={0.8} />
      </mesh>
      <gridHelper args={[16, 32, isActive ? activeColor : inactiveColor, isActive ? activeColor : inactiveColor]} />
      {isActive && (
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[16, 16]} />
          <meshBasicMaterial transparent opacity={0} />
          <Edges scale={1} color={activeColor} />
        </mesh>
      )}
      <Text
        position={[-8.5, 0, 0]}
        rotation={[0, Math.PI / 2, 0]}
        fontSize={0.3}
        color={textColor}
        anchorX="center"
        anchorY="middle"
      >
        {level.name.toUpperCase()}
      </Text>
      <Text
        position={[8.5, 0, 0]}
        rotation={[0, -Math.PI / 2, 0]}
        fontSize={0.3}
        color={textColor}
        anchorX="center"
        anchorY="middle"
        fontStyle="italic"
      >
        {level.axiom}
      </Text>
      <Text
        position={[0, -0.05, -7.5]}
        rotation={[-Math.PI / 2, 0, 0]}
        fontSize={1}
        color={textColor}
        fillOpacity={0.05}
        anchorX="center"
        anchorY="middle"
        letterSpacing={0.2}
      >
        {level.zone}
      </Text>
    </group>
  );
}

function ConcordanceLines({ showDrift, darkMode, entities, concordances }: { showDrift: boolean; darkMode: boolean; entities: Entity[]; concordances: Concordance[] }) {
  const lines = useMemo(() => {
    return concordances.map((c) => {
      const source = entities.find((e) => e.id === c.source);
      const target = entities.find((e) => e.id === c.target);
      if (!source || !target) return null;

      const sourcePos = new THREE.Vector3(source.x ?? (source.type === 'CODE' ? -4 : 4), source.level * LEVEL_HEIGHT, source.y ?? 0);
      const targetPos = new THREE.Vector3(target.x ?? (target.type === 'CODE' ? -4 : 4), target.level * LEVEL_HEIGHT, target.y ?? 0);
      const midPoint = new THREE.Vector3().addVectors(sourcePos, targetPos).multiplyScalar(0.5);

      if (!showDrift && c.status === 'DRIFT') return null;

      return { sourcePos, targetPos, midPoint, ...c };
    }).filter(Boolean) as any[];
  }, [showDrift, entities, concordances]);

  const lineColor = darkMode ? "rgba(255,255,255,0.5)" : "rgba(0,0,0,0.5)";

  return (
    <>
      {lines.map((line, i) => (
        <group key={i}>
          <Line
            points={[line.sourcePos, line.targetPos]}
            color={lineColor}
            lineWidth={line.status === 'SYMMETRIC' ? 1 : 1}
            dashed={line.status === 'DRIFT'}
            dashSize={0.2}
            gapSize={0.2}
            transparent
            opacity={line.score}
          />
          <Text
            position={[line.midPoint.x, line.midPoint.y + 0.1, line.midPoint.z]}
            fontSize={0.15}
            color={lineColor}
            anchorX="center"
            anchorY="middle"
          >
            {line.score.toFixed(2)}
          </Text>
        </group>
      ))}
    </>
  );
}

function UniversePillars({ darkMode }: { darkMode: boolean }) {
  const topY = 12 * LEVEL_HEIGHT;
  const bottomY = -3 * LEVEL_HEIGHT;
  const color = darkMode ? "rgba(255,255,255,0.3)" : "rgba(0,0,0,0.3)";
  const axisColor = darkMode ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.1)";
  
  return (
    <group>
      <Line points={[[-4, bottomY, 0], [-4, topY, 0]]} color={color} dashed dashSize={0.2} gapSize={0.2} />
      <Line points={[[4, bottomY, 0], [4, topY, 0]]} color={color} dashed dashSize={0.2} gapSize={0.2} />
      
      {/* Central Axis */}
      <Line points={[[0, bottomY, 0], [0, topY, 0]]} color={axisColor} lineWidth={2} />
      
      <Text
        position={[-4, bottomY - 1, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        fontSize={0.4}
        color={color}
        anchorX="center"
        anchorY="middle"
      >
        CODOME
      </Text>
      <Text
        position={[4, bottomY - 1, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        fontSize={0.4}
        color={color}
        anchorX="center"
        anchorY="middle"
      >
        CONTEXTOME
      </Text>
    </group>
  );
}

interface HolonStackProps {
  activeLevelId: number;
  showDriftVectors: boolean;
  selectedEntityId: string | null;
  onSelectEntity: (id: string | null) => void;
  darkMode: boolean;
  entities: Entity[];
  concordances: Concordance[];
  onMerge: (sourceId: string, targetId: string) => void;
  onUpdatePosition: (id: string, x: number, y: number) => void;
  setOrbitEnabled: (enabled: boolean) => void;
}

export function HolonStack({ 
  activeLevelId, 
  showDriftVectors, 
  selectedEntityId, 
  onSelectEntity, 
  darkMode,
  entities,
  concordances,
  onMerge,
  onUpdatePosition,
  setOrbitEnabled
}: HolonStackProps) {
  
  const handleDrag = (id: string, x: number, z: number) => {
    onUpdatePosition(id, x, z);
  };

  const handleDragEnd = (id: string, x: number, z: number) => {
    onUpdatePosition(id, x, z);
    
    // Check for merges
    const draggedEntity = entities.find(e => e.id === id);
    if (!draggedEntity) return;

    const MERGE_THRESHOLD = 1.5;
    
    for (const other of entities) {
      if (other.id === id || other.level !== draggedEntity.level) continue;
      
      const otherX = other.x ?? (other.type === 'CODE' ? -4 : 4);
      const otherZ = other.y ?? 0;
      
      const dist = Math.sqrt(Math.pow(x - otherX, 2) + Math.pow(z - otherZ, 2));
      if (dist < MERGE_THRESHOLD) {
        onMerge(id, other.id);
        break; // Only merge with one entity
      }
    }
  };

  return (
    <group onClick={(e) => {
      // Click on background clears selection
      if (e.intersections.length === 0) {
        onSelectEntity(null);
      }
    }}>
      {LEVELS.map((level) => (
        <LevelPlane key={level.id} level={level} isActive={level.id === activeLevelId} darkMode={darkMode} />
      ))}
      {entities.map((entity) => (
        <EntityNode
          key={entity.id}
          entity={entity}
          isActive={entity.level === activeLevelId}
          isSelected={entity.id === selectedEntityId}
          onSelect={() => onSelectEntity(entity.id)}
          darkMode={darkMode}
          setOrbitEnabled={setOrbitEnabled}
          onDrag={handleDrag}
          onDragEnd={handleDragEnd}
        />
      ))}
      <ConcordanceLines showDrift={showDriftVectors} darkMode={darkMode} entities={entities} concordances={concordances} />
      <UniversePillars darkMode={darkMode} />
    </group>
  );
}
