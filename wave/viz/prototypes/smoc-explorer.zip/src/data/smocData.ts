export interface SmocLevel {
  id: number;
  name: string;
  zone: 'PHYSICAL' | 'SYNTACTIC' | 'SEMANTIC' | 'SYSTEMIC' | 'COSMOLOGICAL';
  description: string;
  axiom: string;
  color: string;
  citation: string;
}

export interface Entity {
  id: string;
  name: string;
  level: number;
  type: 'CODE' | 'CONTEXT';
  role?: string;
  description?: string;
  x?: number;
  y?: number;
  antimatter?: string;
}

export interface Concordance {
  source: string;
  target: string;
  status: 'SYMMETRIC' | 'DRIFT' | 'ORPHAN' | 'PHANTOM';
  score: number;
}

export const LEVELS: SmocLevel[] = [
  { id: -3, name: 'L-3 BIT/QUBIT', zone: 'PHYSICAL', description: 'Fundamental unit of information', axiom: 'H(X) = -\\sum p(x) \\log p(x)', color: '#000000', citation: '[Shannon, 1948]' },
  { id: -2, name: 'L-2 BYTE', zone: 'PHYSICAL', description: 'Addressable memory unit', axiom: 'M \\in B^8', color: '#000000', citation: '[von Neumann, 1945]' },
  { id: -1, name: 'L-1 CHARACTER', zone: 'PHYSICAL', description: 'Encoded symbol representation', axiom: '\\sigma \\in \\Sigma_{UTF8}', color: '#000000', citation: '[ASCII/Unicode]' },
  { id: 0, name: 'L0 TOKEN', zone: 'SYNTACTIC', description: 'Atomic unit of language syntax', axiom: '\\tau \\in L_{lex}', color: '#000000', citation: '[Chomsky, 1956]' },
  { id: 1, name: 'L1 STATEMENT', zone: 'SEMANTIC', description: 'Atomic logical instruction', axiom: 'S \\vdash \\phi', color: '#000000', citation: '[Hoare, 1969]' },
  { id: 2, name: 'L2 BLOCK', zone: 'SEMANTIC', description: 'Control flow structure', axiom: '\\{S_1; S_2; ... S_n\\}', color: '#000000', citation: '[Dijkstra, 1968]' },
  { id: 3, name: 'L3 NODE', zone: 'SEMANTIC', description: 'Functional behavior unit (function)', axiom: 'f: X \\to Y', color: '#000000', citation: '[Church, 1936]' },
  { id: 4, name: 'L4 CONTAINER', zone: 'SYSTEMIC', description: 'State + behavior encapsulation (class)', axiom: 'C = \\langle\\Sigma, \\delta\\rangle', color: '#000000', citation: '[Parnas, 1972]' },
  { id: 5, name: 'L5 FILE', zone: 'SYSTEMIC', description: 'Compilation unit', axiom: 'F \\subset FS', color: '#000000', citation: '[Ritchie, 1978]' },
  { id: 6, name: 'L6 PACKAGE', zone: 'SYSTEMIC', description: 'Distribution unit', axiom: 'P = \\{F_i\\} \\cup \\Delta_{dep}', color: '#000000', citation: '[NPM/Cargo]' },
  { id: 7, name: 'L7 SYSTEM', zone: 'SYSTEMIC', description: 'Autonomous operational unit', axiom: 'S_{sys} \\models R_{req}', color: '#000000', citation: '[Sommerville, 2011]' },
  { id: 8, name: 'L8 ECOSYSTEM', zone: 'COSMOLOGICAL', description: 'Interacting systems graph', axiom: 'G = (V_{sys}, E_{int})', color: '#000000', citation: '[Conway, 1968]' },
  { id: 9, name: 'L9 PLATFORM', zone: 'COSMOLOGICAL', description: 'Substrate infrastructure', axiom: '\\Pi \\vdash G', color: '#000000', citation: '[Platform Eng.]' },
  { id: 10, name: 'L10 ORGANIZATION', zone: 'COSMOLOGICAL', description: 'Human hierarchical structure', axiom: 'O \\supset S_{sys}', color: '#000000', citation: "[Conway's Law]" },
  { id: 11, name: 'L11 DOMAIN', zone: 'COSMOLOGICAL', description: 'Abstract problem space', axiom: 'D \\cap S \\neq \\emptyset', color: '#000000', citation: '[DDD, Evans]' },
  { id: 12, name: 'L12 UNIVERSE', zone: 'COSMOLOGICAL', description: 'Total existence context', axiom: 'U = \\top', color: '#000000', citation: '[SMoC Theory]' },
];

export const ENTITIES: Entity[] = [
  // L7 System level
  { id: 'e1', name: 'AuthSystem', level: 7, type: 'CODE', role: 'System', x: -4, y: 0 },
  { id: 'e2', name: 'AUTH_SPEC.md', level: 7, type: 'CONTEXT', role: 'Spec', x: 4, y: 0 },
  { id: 'e16', name: 'BillingSystem', level: 7, type: 'CODE', role: 'System', x: -6, y: -2 },
  { id: 'e17', name: 'BILLING_SPEC.md', level: 7, type: 'CONTEXT', role: 'Spec', x: 6, y: -2 },

  // L6 Package level
  { id: 'e3', name: 'users', level: 6, type: 'CODE', role: 'Package', x: -4, y: 2 },
  { id: 'e4', name: 'users/README.md', level: 6, type: 'CONTEXT', role: 'ReadMe', x: 4, y: 2 },
  { id: 'e5', name: 'core', level: 6, type: 'CODE', role: 'Lib', x: -8, y: -2 },
  { id: 'e18', name: 'payments', level: 6, type: 'CODE', role: 'Package', x: -6, y: -4 },
  { id: 'e19', name: 'payments/README.md', level: 6, type: 'CONTEXT', role: 'ReadMe', x: 6, y: -4 },

  // L5 File level
  { id: 'e6', name: 'user_service.py', level: 5, type: 'CODE', role: 'Module', x: -4, y: 1 },
  { id: 'e7', name: 'user_repo.py', level: 5, type: 'CODE', role: 'Module', x: -6, y: -1, antimatter: 'AM002: Reverse Dependency' },
  { id: 'e20', name: 'stripe_client.py', level: 5, type: 'CODE', role: 'Module', x: -8, y: -3 },
  { id: 'e21', name: 'Stripe API Docs', level: 5, type: 'CONTEXT', role: 'External', x: 8, y: -3 },

  // L4 Container/Class level
  { id: 'e8', name: 'UserService', level: 4, type: 'CODE', role: 'Service', x: -4, y: 2, antimatter: 'AM003: God Class' },
  { id: 'e9', name: 'UserRepository', level: 4, type: 'CODE', role: 'Repository', x: -6, y: -2 },
  { id: 'e10', name: 'Docstring: UserService', level: 4, type: 'CONTEXT', role: 'Docstring', x: 4, y: 2 },
  { id: 'e11', name: 'StringHelper', level: 4, type: 'CODE', role: 'Helper', x: -8, y: 0 },
  { id: 'e22', name: 'PaymentProcessor', level: 4, type: 'CODE', role: 'Service', x: -6, y: -4 },
  { id: 'e23', name: 'Docstring: PaymentProcessor', level: 4, type: 'CONTEXT', role: 'Docstring', x: 6, y: -4 },

  // L3 Node/Function level
  { id: 'e12', name: 'create_user', level: 3, type: 'CODE', role: 'Command', x: -4, y: 2 },
  { id: 'e13', name: 'get_user', level: 3, type: 'CODE', role: 'Query', x: -6, y: -2 },
  { id: 'e14', name: 'API Spec: POST /users', level: 3, type: 'CONTEXT', role: 'Endpoint', x: 4, y: 2 },
  { id: 'e15', name: 'validate_email', level: 3, type: 'CODE', role: 'Check', x: -8, y: 0 },
  { id: 'e24', name: 'charge_card', level: 3, type: 'CODE', role: 'Command', x: -6, y: -4, antimatter: 'AM005: Bounded Context Violation' },
  { id: 'e25', name: 'API Spec: POST /charge', level: 3, type: 'CONTEXT', role: 'Endpoint', x: 6, y: -4 },
];

export const CONCORDANCES: Concordance[] = [
  { source: 'e2', target: 'e1', status: 'SYMMETRIC', score: 0.95 },
  { source: 'e17', target: 'e16', status: 'SYMMETRIC', score: 0.88 },
  { source: 'e4', target: 'e3', status: 'SYMMETRIC', score: 0.80 },
  { source: 'e19', target: 'e18', status: 'DRIFT', score: 0.45 },
  { source: 'e21', target: 'e20', status: 'SYMMETRIC', score: 0.92 },
  { source: 'e10', target: 'e8', status: 'DRIFT', score: 0.60 },
  { source: 'e23', target: 'e22', status: 'SYMMETRIC', score: 0.85 },
  { source: 'e14', target: 'e12', status: 'SYMMETRIC', score: 0.90 },
  { source: 'e25', target: 'e24', status: 'DRIFT', score: 0.30 },
];
