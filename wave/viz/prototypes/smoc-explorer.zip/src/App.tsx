/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SmocScene } from './components/SmocScene';

export default function App() {
  return <SmocScene />;
}
