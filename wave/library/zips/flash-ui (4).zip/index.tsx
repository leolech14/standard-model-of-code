
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

//Vibe coded by ammaar@google.com

import { GoogleGenAI } from '@google/genai';
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';

import { Artifact, Session } from './types';
import { INITIAL_PLACEHOLDERS } from './constants';
import { generateId } from './utils';

import DottedGlowBackground from './components/DottedGlowBackground';
import ArtifactCard from './components/ArtifactCard';
import SideDrawer from './components/SideDrawer';
import { 
    ThinkingIcon, 
    CodeIcon, 
    SparklesIcon, 
    ArrowLeftIcon, 
    ArrowRightIcon, 
    ArrowUpIcon, 
    GridIcon,
    ExportIcon,
    ImageIcon,
    CopyIcon,
    CheckIcon,
    DownloadIcon
} from './components/Icons';

/**
 * ExportManager handles the transformation of raw HTML artifacts 
 * into framework-specific code using Gemini.
 */
interface ExportManagerProps {
    html: string;
}

const ExportManager = ({ html }: ExportManagerProps) => {
    const [activeTab, setActiveTab] = useState<'html' | 'react' | 'vue' | 'angular'>('html');
    const [transformedCode, setTransformedCode] = useState<Record<string, string>>({ html });
    const [isTransforming, setIsTransforming] = useState(false);
    const [copied, setCopied] = useState(false);

    const transformCode = async (framework: 'react' | 'vue' | 'angular') => {
        if (transformedCode[framework]) {
            setActiveTab(framework);
            return;
        }

        setIsTransforming(true);
        setActiveTab(framework);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
            const prompt = `Transform the following UI code into a highly sophisticated, production-ready ${framework} component. 
            Use best practices for ${framework}, including appropriate hooks/directives, scoped styles or Tailwind-like classes, and clear structure. 
            Ensure the output is one single, self-contained file.
            Return ONLY the raw code. No markdown formatting markers.
            
            CODE TO TRANSFORM:
            ${html}`;

            const result = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: [{ parts: [{ text: prompt }] }]
            });

            const code = result.text?.replace(/```[a-z]*\n|```/g, '').trim() || '';
            setTransformedCode(prev => ({ ...prev, [framework]: code }));
        } catch (error) {
            console.error('Transformation failed:', error);
        } finally {
            setIsTransforming(false);
        }
    };

    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const downloadFile = (text: string) => {
        const extensions: Record<string, string> = {
            html: 'html',
            react: 'tsx',
            vue: 'vue',
            angular: 'ts'
        };
        const blob = new Blob([text], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `flash-component.${extensions[activeTab] || 'txt'}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="export-manager">
            <div className="export-tabs">
                <button className={activeTab === 'html' ? 'active' : ''} onClick={() => setActiveTab('html')}>HTML/CSS</button>
                <button className={activeTab === 'react' ? 'active' : ''} onClick={() => transformCode('react')}>React</button>
                <button className={activeTab === 'vue' ? 'active' : ''} onClick={() => transformCode('vue')}>Vue</button>
                <button className={activeTab === 'angular' ? 'active' : ''} onClick={() => transformCode('angular')}>Angular</button>
            </div>
            
            <div className="export-content">
                {isTransforming ? (
                    <div className="transform-loading">
                        <ThinkingIcon />
                        <p>Synthesizing {activeTab.toUpperCase()} Architecture...</p>
                    </div>
                ) : (
                    <div className="code-viewer-container">
                        <div className="code-toolbar">
                            <span className="lang-badge">{activeTab.toUpperCase()}</span>
                            <div className="code-actions">
                                <button className={`action-btn ${copied ? 'success' : ''}`} onClick={() => copyToClipboard(transformedCode[activeTab])}>
                                    {copied ? <><CheckIcon /> Copied</> : <><CopyIcon /> Copy</>}
                                </button>
                                <button className="action-btn" onClick={() => downloadFile(transformedCode[activeTab])}>
                                    <DownloadIcon /> Download
                                </button>
                            </div>
                        </div>
                        <pre className="code-display">
                            <code>{transformedCode[activeTab] || '// Transformation pending...'}</code>
                        </pre>
                    </div>
                )}
            </div>
        </div>
    );
};

function App() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [currentSessionIndex, setCurrentSessionIndex] = useState<number>(-1);
  const [focusedArtifactIndex, setFocusedArtifactIndex] = useState<number | null>(null);
  
  const [inputValue, setInputValue] = useState<string>('');
  const [uploadedImage, setUploadedImage] = useState<{data: string, mimeType: string} | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [processingStep, setProcessingStep] = useState<string>('');
  const [logs, setLogs] = useState<string[]>(["Flash Intelligence V3 Online", "System stabilized. Design engine ready."]);
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [placeholders] = useState<string[]>(INITIAL_PLACEHOLDERS);
  
  const [drawerState, setDrawerState] = useState<{
      isOpen: boolean;
      mode: 'code' | 'export' | null;
      title: string;
      data: string | null; 
  }>({ isOpen: false, mode: null, title: '', data: null });

  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  const addLog = useCallback((msg: string) => {
    setLogs(prev => {
        const timestamp = new Date().toLocaleTimeString([], {hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit'});
        return [...prev.slice(-15), `[${timestamp}] ${msg}`];
    });
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        addLog(`Analyzing visual DNA: ${file.name}`);
        const reader = new FileReader();
        reader.onload = (event) => {
            const base64 = event.target?.result as string;
            const [mimeTypePart, dataPart] = base64.split(';base64,');
            setUploadedImage({ data: dataPart, mimeType: mimeTypePart.split(':')[1] });
            addLog("Image indexed. Multimodal synthesis ready.");
            inputRef.current?.focus();
        };
        reader.readAsDataURL(file);
    }
  };

  const handleSendMessage = useCallback(async (manualPrompt?: string, parentArtifactId?: string) => {
    const promptToUse = (manualPrompt || inputValue).trim();
    if ((!promptToUse && !uploadedImage) || isLoading) return;
    
    setIsLoading(true);
    setFocusedArtifactIndex(null); 
    
    setProcessingStep('Synthesizing Design Core...');
    addLog(uploadedImage ? "Performing cross-modal heuristic mapping..." : "Initializing design synthesis...");
    
    const sessionId = generateId();
    const placeholderArtifacts: Artifact[] = Array(3).fill(null).map((_, i) => ({
        id: `${sessionId}_${i}`,
        styleName: 'Thinking...',
        html: '',
        status: 'streaming',
    }));

    const sessionPrompt = promptToUse || (uploadedImage ? "Visual Evolution" : "New Vision");
    const newSession: Session = {
        id: sessionId,
        prompt: sessionPrompt,
        timestamp: Date.now(),
        artifacts: placeholderArtifacts,
        parentArtifactId: parentArtifactId
    };

    setSessions(prev => {
        const newIdx = prev.length;
        setCurrentSessionIndex(newIdx);
        return [...prev, newSession];
    });

    if (!manualPrompt) setInputValue('');

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

        const stylePrompt = `Act as a senior UI engineer and creative director. For the prompt "${promptToUse}", provide 3 distinct high-fidelity design directions.
        Return ONLY a JSON array of 3 string names. Format: ["Direction 1", "Direction 2", "Direction 3"]`;

        const styleResult = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: [{ 
                parts: [
                    ...(uploadedImage ? [{ inlineData: { data: uploadedImage.data, mimeType: uploadedImage.mimeType } }] : []),
                    { text: stylePrompt }
                ] 
            }]
        });

        let generatedStyles: string[] = ["Modern Precise", "Fluid Organic", "Brutalist Mono"];
        try {
            const rawText = styleResult.text || '[]';
            const jsonMatch = rawText.match(/\[[\s\S]*\]/);
            if (jsonMatch) generatedStyles = JSON.parse(jsonMatch[0]);
        } catch (e) { addLog("Heuristic fallback triggered."); }

        setSessions(prev => prev.map(s => s.id === sessionId ? {
            ...s, artifacts: s.artifacts.map((art, i) => ({...art, styleName: generatedStyles[i] || "Hifi Prototype"}))
        } : s));

        setProcessingStep('Forging Artifacts...');
        addLog(`Mapping ${generatedStyles.length} design branches.`);
        
        const capturedImage = uploadedImage;
        setUploadedImage(null); 

        const generateArtifact = async (artifact: Artifact, styleInstruction: string) => {
            const basePrompt = `Act as a world-class Lead Frontend Architect. Create a single-file, production-ready, highly sophisticated UI component for: "${promptToUse}". 
            
            DESIGN SYSTEM DIRECTION: ${styleInstruction}.

            SOPHISTICATION REQUIREMENTS:
            - Layout: Use CSS Grid or Flexbox with meticulous spatial rhythm (8px spacing scale). Prefer Bento Grids, Fluid Masonry, or Modern Split Layouts.
            - Typography: Use fluid typography (clamp()) and elite font pairings (e.g., Inter with a sophisticated mono).
            - Motion: Implement elite motion design. Use CSS transforms and opacity for performant, spring-like transitions on hover/focus/active.
            - Visual Style: Use absolute high-end techniques: layered box-shadows (6+ layers), glassmorphism (backdrop-filter: blur(20px)), subtle mesh gradients, and 0.5px - 1px borders.
            - Micro-interactions: Everything should react. Scale-down on click, lift on hover, glow on focus.
            - Quality: Fully responsive, semantic HTML5, high-contrast accessiblity.
            - Output: Return ONLY the code (HTML + Scoped CSS + Script). NO markdown wrappers. Ensure it looks like a premium finished product.`;
      
            addLog(`Crafting ${styleInstruction} variant...`);
            
            const responseStream = await ai.models.generateContentStream({
                model: 'gemini-3-flash-preview',
                contents: [{ 
                    parts: [
                        ...(capturedImage ? [{ inlineData: { data: capturedImage.data, mimeType: capturedImage.mimeType } }] : []),
                        { text: basePrompt }
                    ]
                }],
            });

            let accumulatedHtml = '';
            for await (const chunk of responseStream) {
                accumulatedHtml += chunk.text || '';
                setSessions(prev => prev.map(sess => 
                    sess.id === sessionId ? {
                        ...sess,
                        artifacts: sess.artifacts.map(art => 
                            art.id === artifact.id ? { ...art, html: accumulatedHtml } : art
                        )
                    } : sess
                ));
            }
            
            const finalHtml = accumulatedHtml.replace(/```[a-z]*\n|```/g, '').trim();
            setSessions(prev => prev.map(sess => 
                sess.id === sessionId ? {
                    ...sess,
                    artifacts: sess.artifacts.map(art => 
                        art.id === artifact.id ? { ...art, html: finalHtml, status: 'complete' } : art
                    )
                } : sess
            ));
        };

        await Promise.all(placeholderArtifacts.map((art, i) => generateArtifact(art, generatedStyles[i])));
    } catch (e) {
        console.error("Critical failure:", e);
        addLog("System self-healed after pipeline error.");
    } finally {
        setIsLoading(false);
        setProcessingStep('');
        addLog("Iteration complete. All branches stabilized.");
    }
  }, [inputValue, uploadedImage, isLoading, sessions.length, addLog]);

  const handleBranchGeneration = useCallback(() => {
    const currentSession = sessions[currentSessionIndex];
    if (!currentSession || focusedArtifactIndex === null) return;
    const parentArtifact = currentSession.artifacts[focusedArtifactIndex];
    handleSendMessage(`Evolve and expand design: ${currentSession.prompt}`, parentArtifact.id);
  }, [sessions, currentSessionIndex, focusedArtifactIndex, handleSendMessage]);

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') handleSendMessage();
    else if (event.key === 'Tab' && !inputValue) {
        event.preventDefault();
        setInputValue(placeholders[placeholderIndex]);
        setPlaceholderIndex(prev => (prev + 1) % placeholders.length);
    }
  };

  const hasStarted = sessions.length > 0 || isLoading;
  const currentSession = sessions[currentSessionIndex];

  return (
    <div className="immersive-app">
        <DottedGlowBackground gap={24} color="rgba(255, 255, 255, 0.02)" glowColor="rgba(255, 255, 255, 0.08)" />

        <div className={`stage-container ${focusedArtifactIndex !== null ? 'mode-focus' : ''}`}>
             <div className={`empty-state ${hasStarted ? 'fade-out' : ''}`}>
                 <div className="empty-content">
                     <h1>Flash UI</h1>
                     <p>Rapid synthesis of professional interfaces</p>
                     <div className="hero-actions">
                         <button className="surprise-button" onClick={() => handleSendMessage(placeholders[Math.floor(Math.random()*placeholders.length)])}><SparklesIcon /> Quick Start</button>
                         <button className="copycat-button" onClick={() => fileInputRef.current?.click()}><ImageIcon /> Start with Visuals</button>
                     </div>
                 </div>
             </div>

            {sessions.map((session, sIndex) => (
                <div key={session.id} className={`session-group ${sIndex === currentSessionIndex ? 'active-session' : ''}`}>
                    <div className="artifact-grid">
                        {session.artifacts.map((artifact, aIndex) => (
                            <ArtifactCard 
                                key={artifact.id}
                                artifact={artifact} 
                                isFocused={focusedArtifactIndex === aIndex} 
                                isActive={sIndex === currentSessionIndex}
                                onClick={() => setFocusedArtifactIndex(aIndex)} 
                            />
                        ))}
                    </div>
                </div>
            ))}
        </div>

        {currentSessionIndex > 0 && (
            <button className="nav-handle left" onClick={() => setCurrentSessionIndex(prev => prev - 1)} aria-label="Previous"><ArrowLeftIcon /></button>
        )}
        {currentSessionIndex < sessions.length - 1 && (
            <button className="nav-handle right" onClick={() => setCurrentSessionIndex(prev => prev + 1)} aria-label="Next"><ArrowRightIcon /></button>
        )}

        <div className={`action-bar ${focusedArtifactIndex !== null ? 'visible' : ''}`}>
             <div className="action-buttons">
                <button onClick={() => setFocusedArtifactIndex(null)}><GridIcon /> View All</button>
                <button onClick={handleBranchGeneration} disabled={isLoading}><SparklesIcon /> Iterate Design</button>
                <button onClick={() => setDrawerState({ isOpen: true, mode: 'export', title: 'Export Engine', data: currentSession?.artifacts[focusedArtifactIndex!]?.html })}><ExportIcon /> Export</button>
             </div>
        </div>

        <div className="floating-input-container">
            <input type="file" ref={fileInputRef} style={{display: 'none'}} accept="image/*" onChange={handleFileChange} />
            <div className={`input-wrapper ${isLoading ? 'generating' : ''} ${uploadedImage ? 'has-image' : ''}`}>
                <button className="upload-btn" style={{all: 'unset', cursor: 'pointer', paddingRight: 12, display: 'flex', alignItems: 'center'}} onClick={() => fileInputRef.current?.click()} disabled={isLoading}><ImageIcon /></button>
                {uploadedImage && (
                    <div className="img-pvw">
                        <img src={`data:${uploadedImage.mimeType};base64,${uploadedImage.data}`} alt="Upload preview" />
                        <button className="img-pvw-remove" onClick={() => setUploadedImage(null)} aria-label="Remove image">&times;</button>
                    </div>
                )}
                <input ref={inputRef} type="text" value={inputValue} onChange={(e) => setInputValue(e.target.value)} onKeyDown={handleKeyDown} placeholder={isLoading ? processingStep : "Describe the interface..."} disabled={isLoading} />
                <button className="send-button" onClick={() => handleSendMessage()} disabled={isLoading} aria-label="Send"><ArrowUpIcon /></button>
            </div>
        </div>

        <div className="activity-ticker">
            <div className="ticker-inner">
                {logs.map((log, i) => <span key={i} className="ticker-item">{log}</span>)}
                {logs.map((log, i) => <span key={`dup-${i}`} className="ticker-item">{log}</span>)}
            </div>
        </div>

        <SideDrawer isOpen={drawerState.isOpen} onClose={() => setDrawerState(s => ({...s, isOpen: false}))} title={drawerState.title}>
            {drawerState.mode === 'export' && drawerState.data && (
                <ExportManager html={drawerState.data} />
            )}
        </SideDrawer>
    </div>
  );
}

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = createRoot(rootElement);
  root.render(<App />);
}
