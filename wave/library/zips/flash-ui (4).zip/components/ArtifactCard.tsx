
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useEffect, useRef, useState } from 'react';
import { Artifact } from '../types';
import { CopyIcon, CheckIcon, DownloadIcon, ExportIcon, ThinkingIcon } from './Icons';
import { GoogleGenAI } from '@google/genai';

interface ArtifactCardProps {
    artifact: Artifact;
    isFocused: boolean;
    isActive: boolean;
    onClick: () => void;
}

type ViewportMode = 'desktop' | 'tablet' | 'mobile';
type FrameworkMode = 'preview' | 'react' | 'vue' | 'angular';

const ArtifactCard = React.memo(({ 
    artifact, 
    isFocused, 
    isActive,
    onClick 
}: ArtifactCardProps) => {
    const cardRef = useRef<HTMLDivElement>(null);
    const contentAreaRef = useRef<HTMLDivElement>(null);
    const [scale, setScale] = useState(1);
    const [viewportMode, setViewportMode] = useState<ViewportMode>('desktop');
    const [frameworkMode, setFrameworkMode] = useState<FrameworkMode>('preview');
    
    const [transformedCode, setTransformedCode] = useState<Record<string, string>>({});
    const [isTransforming, setIsTransforming] = useState(false);
    const [copied, setCopied] = useState(false);
    const [showExportMenu, setShowExportMenu] = useState(false);

    useEffect(() => {
        if (isActive && contentAreaRef.current) {
            const updateScale = () => {
                if (!contentAreaRef.current) return;
                
                const areaWidth = contentAreaRef.current.clientWidth;
                const areaHeight = contentAreaRef.current.clientHeight;
                
                const baseWidth = viewportMode === 'desktop' ? 1280 : viewportMode === 'tablet' ? 768 : 390;
                const baseHeight = viewportMode === 'desktop' ? 800 : viewportMode === 'tablet' ? 1024 : 844;
                
                if (areaWidth === 0 || areaHeight === 0) return;

                const scaleX = areaWidth / baseWidth;
                const scaleY = areaHeight / baseHeight;
                
                let finalScale = isFocused ? Math.min(scaleX, scaleY) : scaleX;
                finalScale = finalScale * (isFocused ? 0.95 : 1.0);
                
                setScale(Math.max(0.05, finalScale));
            };
            
            updateScale();
            const ro = new ResizeObserver(updateScale);
            ro.observe(contentAreaRef.current);
            window.addEventListener('resize', updateScale);
            
            return () => {
                ro.disconnect();
                window.removeEventListener('resize', updateScale);
            }
        }
    }, [isFocused, isActive, viewportMode]);

    const handleFrameworkSwitch = async (mode: FrameworkMode) => {
        setFrameworkMode(mode);
        if (mode === 'preview' || transformedCode[mode]) return;

        setIsTransforming(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
            const prompt = `Transform the following UI code into a production-ready ${mode} component. 
            Use best practices for ${mode}, including hooks/directives and modular CSS/Tailwind.
            Return ONLY raw code.
            
            CODE:
            ${artifact.html}`;

            const result = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: [{ parts: [{ text: prompt }] }]
            });

            const code = result.text?.replace(/```[a-z]*\n|```/g, '').trim() || '';
            setTransformedCode(prev => ({ ...prev, [mode]: code }));
        } catch (error) {
            console.error('Transformation failed:', error);
        } finally {
            setIsTransforming(false);
        }
    };

    const handleCopyCode = (e: React.MouseEvent) => {
        e.stopPropagation();
        const codeToCopy = frameworkMode === 'preview' ? artifact.html : transformedCode[frameworkMode];
        if (!codeToCopy) return;
        
        navigator.clipboard.writeText(codeToCopy).then(() => {
            setCopied(true);
            setTimeout(() => {
                setCopied(false);
                setShowExportMenu(false);
            }, 2500);
        });
    };

    const handleDownloadCode = (e: React.MouseEvent) => {
        e.stopPropagation();
        const codeToDownload = frameworkMode === 'preview' ? artifact.html : transformedCode[frameworkMode];
        if (!codeToDownload) return;
        
        const ext = frameworkMode === 'preview' ? 'html' : frameworkMode === 'react' ? 'tsx' : frameworkMode === 'vue' ? 'vue' : 'ts';
        const blob = new Blob([codeToDownload], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `flash-ui-export.${ext}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setShowExportMenu(false);
    };

    const toggleExportMenu = (e: React.MouseEvent) => {
        e.stopPropagation();
        setShowExportMenu(prev => !prev);
    };

    const isGenerating = artifact.status === 'streaming';
    const hasContent = artifact.html && artifact.html.trim().length > 0;

    const viewportStyles = {
        desktop: { width: '1280px', height: '800px' },
        tablet: { width: '768px', height: '1024px' },
        mobile: { width: '390px', height: '844px' }
    };

    const currentViewport = viewportStyles[viewportMode];

    return (
        <div 
            ref={cardRef}
            className={`artifact-card-wrapper ${isFocused ? 'focused' : ''} ${isGenerating ? 'is-generating' : ''}`}
            onClick={isFocused ? undefined : onClick}
        >
            <div className="artifact-toolbar">
                <div className="artifact-info">
                    <span className="style-badge">{artifact.styleName}</span>
                    {hasContent && (
                        <div className="export-container">
                            <button 
                                className={`card-export-trigger ${showExportMenu ? 'active' : ''}`} 
                                onClick={toggleExportMenu}
                            >
                                <ExportIcon />
                            </button>
                            {showExportMenu && (
                                <div className="export-popover" onClick={(e) => e.stopPropagation()}>
                                    <div className="popover-header">Export Engine</div>
                                    <button onClick={handleCopyCode} className={`popover-btn ${copied ? 'success' : ''}`}>
                                        {copied ? <CheckIcon /> : <CopyIcon />}
                                        {copied ? 'Copied' : `Copy ${frameworkMode === 'preview' ? 'HTML' : frameworkMode.toUpperCase()}`}
                                    </button>
                                    <button onClick={handleDownloadCode} className="popover-btn">
                                        <DownloadIcon />
                                        Download File
                                    </button>
                                </div>
                            )}
                        </div>
                    )}
                </div>
                <div className="viewport-controls" onClick={(e) => e.stopPropagation()}>
                    <button className={viewportMode === 'mobile' ? 'active' : ''} onClick={() => setViewportMode('mobile')}><ViewportMobileIcon /></button>
                    <button className={viewportMode === 'tablet' ? 'active' : ''} onClick={() => setViewportMode('tablet')}><ViewportTabletIcon /></button>
                    <button className={viewportMode === 'desktop' ? 'active' : ''} onClick={() => setViewportMode('desktop')}><ViewportDesktopIcon /></button>
                </div>
            </div>
            
            <div className={`artifact-device-frame ${viewportMode}`}>
                <div className="browser-header">
                    <div className="browser-dots"><span></span><span></span><span></span></div>
                    <div className="browser-address">flash-ui.ai/{artifact.styleName.toLowerCase().replace(/\s+/g, '-')}</div>
                </div>

                <div className="browser-tabs-row" onClick={(e) => e.stopPropagation()}>
                    <button className={frameworkMode === 'preview' ? 'active' : ''} onClick={() => handleFrameworkSwitch('preview')}>Preview</button>
                    <button className={frameworkMode === 'react' ? 'active' : ''} onClick={() => handleFrameworkSwitch('react')}>React</button>
                    <button className={frameworkMode === 'vue' ? 'active' : ''} onClick={() => handleFrameworkSwitch('vue')}>Vue</button>
                    <button className={frameworkMode === 'angular' ? 'active' : ''} onClick={() => handleFrameworkSwitch('angular')}>Angular</button>
                </div>
                
                <div className="artifact-content-area" ref={contentAreaRef}>
                    {frameworkMode === 'preview' ? (
                        <div 
                            className="artifact-iframe-container" 
                            style={{ 
                                width: currentViewport.width,
                                height: currentViewport.height,
                                transform: `scale(${scale})`,
                                opacity: hasContent ? 1 : (isGenerating ? 0 : 0.2)
                            }}
                        >
                            <iframe 
                                srcDoc={artifact.html} 
                                title={artifact.id} 
                                sandbox="allow-scripts allow-forms allow-modals allow-popups allow-presentation allow-same-origin"
                                className="artifact-iframe"
                            />
                        </div>
                    ) : (
                        <div className="card-code-viewer">
                            {isTransforming ? (
                                <div className="card-code-loading">
                                    <ThinkingIcon />
                                    <span>Synthesizing Architecture...</span>
                                </div>
                            ) : (
                                <pre>
                                    <code>{transformedCode[frameworkMode] || '// Transform Pending...'}</code>
                                </pre>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
});

// Helper Icons
const ViewportMobileIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>;
const ViewportTabletIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>;
const ViewportDesktopIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>;

export default ArtifactCard;
