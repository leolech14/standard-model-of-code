
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useEffect, useRef, useState, useCallback } from 'react';
// Added missing icon imports from lucide-react
import { Sparkles, Brain } from 'lucide-react';
import { InkSimulation } from './services/inkSimulation';
import { ControlPanel } from './components/ControlPanel';
import VoiceStatus from './components/VoiceStatus';
import { SettingsPill } from './components/SettingsPill';
import { LiveClient } from './services/liveApi';
import { ImageTracer, Stroke } from './services/imageTracer';
import { BrushType, PaperType, SimulationParams, PaperParams, LiveState, ToolHandler, AIOperationState, Snapshot, PaintingPlan, HarmonyAnalysis, AspectRatio } from './types';
import { DEFAULT_SETTINGS } from './defaultConfig';
import { COLOR } from './services/colorEngine';

const App: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const simRef = useRef<InkSimulation | null>(null);
  const animationRef = useRef<number | null>(null);
  const isMouseDown = useRef(false);
  const lastPos = useRef<{ x: number; y: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const isMounted = useRef(true);
  
  const [params, setParams] = useState<SimulationParams>(DEFAULT_SETTINGS.simulation);
  const [paperParams, setPaperParams] = useState<PaperParams>(DEFAULT_SETTINGS.paper);
  const [isSettingsMinimized, setIsSettingsMinimized] = useState(false);
  const [layoutMode, setLayoutMode] = useState<'floating' | 'sidebar'>('sidebar');

  const autoPaintRef = useRef<{ strokes: Stroke[], strokeIdx: number, pointIdx: number } | null>(null);
  const [isAutoPainting, setIsAutoPainting] = useState(false);
  const [isTracing, setIsTracing] = useState(false);
  const [traceStatus, setTraceStatus] = useState<string>('');
  const [detectedHarmony, setDetectedHarmony] = useState<HarmonyAnalysis | null>(null);

  const paramsRef = useRef(params);
  useEffect(() => { paramsRef.current = params; }, [params]);

  const paperParamsRef = useRef(paperParams);
  useEffect(() => { paperParamsRef.current = paperParams; }, [paperParams]);

  const [viewMode, setViewMode] = useState<'ink' | 'fibers'>('ink');
  const viewModeRef = useRef(viewMode);
  useEffect(() => { viewModeRef.current = viewMode; }, [viewMode]);

  const [activeTab, setActiveTab] = useState<'paint' | 'brushes' | 'physics' | 'paper' | 'studio' | 'debug'>('paint');
  const [liveState, setLiveState] = useState<LiveState>({ isConnected: false, isSpeaking: false, error: null });
  const liveClientRef = useRef<LiveClient | null>(null);
  const [currentAiOp, setCurrentAiOp] = useState<AIOperationState | null>(null);

  const undoStack = useRef<Snapshot[]>([]);
  const redoStack = useRef<Snapshot[]>([]);

  useEffect(() => {
    isMounted.current = true;
    return () => { isMounted.current = false; };
  }, []);

  const saveSnapshot = useCallback(() => {
    if (!simRef.current) return;
    undoStack.current.push({
      arrays: simRef.current.getSnapshotArrays(),
      params: JSON.parse(JSON.stringify(paramsRef.current)),
      paperParams: JSON.parse(JSON.stringify(paperParamsRef.current))
    });
    if (undoStack.current.length > 20) undoStack.current.shift();
    redoStack.current = [];
  }, []);

  const handleUndo = useCallback(() => {
    if (!simRef.current || undoStack.current.length === 0) return;
    const s = undoStack.current.pop();
    if (s) {
        simRef.current.restoreSnapshotArrays(s.arrays);
        setParams(s.params);
        setPaperParams(s.paperParams);
    }
  }, []);

  const handleUpdateParams = useCallback((updates: Partial<SimulationParams>) => {
    setParams(prev => ({ ...prev, ...updates }));
  }, []);

  const handleUpdatePaper = useCallback((updates: Partial<PaperParams>) => {
    setPaperParams(prev => ({ ...prev, ...updates }));
  }, []);

  const handleClear = useCallback(() => {
      saveSnapshot(); 
      simRef.current?.clear();
      autoPaintRef.current = null;
      setIsAutoPainting(false);
      setIsTracing(false);
      setTraceStatus('');
      setDetectedHarmony(null);
  }, [saveSnapshot]);

  const handleToggleView = useCallback(() => setViewMode(m => m === 'ink' ? 'fibers' : 'ink'), []);
  
  const handleSaveImage = useCallback(() => {
      if (!canvasRef.current) return;
      const link = document.createElement('a');
      link.download = `moxi-ink-${Date.now()}.png`;
      link.href = canvasRef.current.toDataURL('image/png');
      link.click();
  }, []);

  const handleAutoPaintImage = useCallback(async (base64: string, clearFirst: boolean = false, incomingPlan?: PaintingPlan) => {
    try {
        setIsTracing(true);
        setTraceStatus('Reading Image Data...');
        if (clearFirst) handleClear();
        handleUpdatePaper({ resolution: 1024 });
        
        let plan = incomingPlan;
        if (!plan) {
            setTraceStatus('Gemini Vision Analysis...');
            setCurrentAiOp({ type: 'thinking', label: 'Consulting Art Director...', icon: 'brain', autoClear: false });
            if (liveClientRef.current) {
                const b64Data = base64.split(',')[1] || base64;
                plan = await liveClientRef.current.analyzeExternalImage(b64Data);
            }
        }

        setTraceStatus('Synthesizing Painting Strategy...');
        setCurrentAiOp({ type: 'thinking', label: 'Mapping Ink Vectors...', icon: 'spark', autoClear: false });
        await new Promise(r => setTimeout(r, 600));

        setTraceStatus('Deconstructing Form & Geometry...');
        const res = 1024;
        const { strokes, harmony } = await ImageTracer.extractStrokes(base64, res, plan);
        
        setTraceStatus('Optimizing Color Chords...');
        setDetectedHarmony(harmony);
        autoPaintRef.current = { strokes, strokeIdx: 0, pointIdx: 0 };
        setIsAutoPainting(true);
        setIsTracing(false);
        setTraceStatus('');
        setCurrentAiOp({ type: 'action', label: `Executing ${plan?.style || 'Ink'} Trace`, icon: 'palette', autoClear: false });
    } catch (e) {
        console.error("Vision trace failed", e);
        setIsTracing(false);
        setTraceStatus('Failed to process image');
        setCurrentAiOp({ type: 'action', label: 'Analysis Error', icon: 'trash' });
        setTimeout(() => setTraceStatus(''), 3000);
    }
  }, [handleUpdatePaper, handleClear]);

  const handleAiStudioPrompt = useCallback(async (prompt: string, type: 'think' | 'fast' | 'generate', aspectRatio?: AspectRatio) => {
    if (!liveClientRef.current) return;
    try {
      if (type === 'think') {
        setCurrentAiOp({ type: 'thinking', label: 'Deep Reasoning...', icon: 'brain', autoClear: false });
        const result = await liveClientRef.current.think(prompt);
        setCurrentAiOp({ type: 'action', label: 'Thought Synthesized', icon: 'spark', autoClear: true });
        return result;
      } else if (type === 'fast') {
        setCurrentAiOp({ type: 'action', label: 'Processing...', icon: 'spark', autoClear: false });
        const result = await liveClientRef.current.fastQuery(prompt);
        setCurrentAiOp(null);
        return result;
      } else if (type === 'generate') {
        setCurrentAiOp({ type: 'thinking', label: 'Latent Image Synthesis...', icon: 'image', autoClear: false });
        const base64 = await liveClientRef.current.generateImage(prompt, aspectRatio || '1:1');
        setCurrentAiOp({ type: 'action', label: 'Vision Materialized', icon: 'palette', autoClear: true });
        handleAutoPaintImage(base64, true);
      }
    } catch (e) {
      setCurrentAiOp({ type: 'action', label: 'AI Error', icon: 'trash' });
    }
  }, [handleAutoPaintImage]);

  useEffect(() => {
    const toolHandler: ToolHandler = {
        updateSimulation: handleUpdateParams,
        updatePaper: handleUpdatePaper,
        setColor: (l, c, h) => handleUpdateParams({ color: { l, c, h } }),
        switchTab: setActiveTab as any,
        controlApp: (action) => {
            if (action === 'clear') handleClear();
            if (action === 'undo') handleUndo();
            if (action === 'toggleView') handleToggleView();
        },
        importImage: (base64, clearFirst, plan) => {
            handleAutoPaintImage(base64, clearFirst, plan);
        },
        notifyAiState: (label, icon, autoClear, type) => setCurrentAiOp({ type: type || 'action', label, icon, autoClear }),
        getParams: () => paramsRef.current,
        getPaperParams: () => paperParamsRef.current
    };
    liveClientRef.current = new LiveClient(process.env.API_KEY || '', toolHandler, setLiveState);
    return () => liveClientRef.current?.disconnect();
  }, [handleClear, handleUndo, handleToggleView, handleUpdateParams, handleUpdatePaper, handleAutoPaintImage]);

  useEffect(() => {
    setLoading(true);
    const initSim = () => {
      if (!isMounted.current) return;
      const res = paperParams.resolution;
      simRef.current = new InkSimulation(res, res);
      simRef.current.generatePaper(paperParams.type, paperParams.roughness, paperParams.contrast, paperParams.align);
      setLoading(false);
    };
    const tm = setTimeout(initSim, 100);
    return () => clearTimeout(tm);
  }, [paperParams.resolution]);

  useEffect(() => {
    if (!simRef.current || !canvasRef.current || loading) return;
    const res = paperParams.resolution;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const bCanv = document.createElement('canvas');
    bCanv.width = res; bCanv.height = res;
    const bCtx = bCanv.getContext('2d')!;
    const iData = bCtx.createImageData(res, res);
    const u32 = new Uint32Array(iData.data.buffer);
    
    const render = () => {
      if (!isMounted.current || !simRef.current || !canvasRef.current) return;
      const sim = simRef.current;

      if (autoPaintRef.current) {
        const { strokes, strokeIdx } = autoPaintRef.current;
        if (strokeIdx < strokes.length) {
          const s = strokes[strokeIdx];
          const ptsPerF = (s.priority === 1) ? 75 : (s.priority === 0 ? 20 : 40); 
          
          for (let p = 0; p < ptsPerF; p++) {
            const pi = autoPaintRef.current.pointIdx;
            if (pi < s.points.length) {
              const pt = s.points[pi];
              const rgb = COLOR.toRGB(pt.color);
              const rS = sim.w / 256;
              const cfg = s.brushConfig;
              sim.addInput(
                pt.x, pt.y, 
                cfg.size * s.thicknessMod * rS,
                (cfg.water / 100) * (s.priority === 1 ? 0.98 : 0.85), 
                (cfg.ink / 20) * pt.pressure * (s.priority === 1 ? 0.3 : 1.0), 
                rgb.r, rgb.g, rgb.b, 
                pt.vx, pt.vy
              );
              autoPaintRef.current.pointIdx++;
            } else {
              autoPaintRef.current.strokeIdx++;
              autoPaintRef.current.pointIdx = 0;
              break; 
            }
          }
        } else {
          autoPaintRef.current = null;
          setIsAutoPainting(false);
          setCurrentAiOp(null);
        }
      }

      sim.setParams(paramsRef.current.dryingSpeed, paramsRef.current.viscosity, paramsRef.current.paperResist, paramsRef.current.inkWeight);
      sim.brushType = paramsRef.current.brushType;
      sim.step();

      const { w, h, fibers, cFixed, mFixed, yFixed, cFloating, mFloating, yFloating } = sim;
      const len = w * h;
      const dark = document.documentElement.classList.contains('dark');

      for (let i = 0; i < len; i++) {
        const C = cFixed[i] + cFloating[i], M = mFixed[i] + mFloating[i], Y = yFixed[i] + yFloating[i];
        const pV = dark ? (25 - fibers[i] * 12) : (255 - fibers[i] * 15);
        let r, g, b;
        if (C < 0.001 && M < 0.001 && Y < 0.001) {
            u32[i] = (255 << 24) | (pV << 16) | (pV << 8) | pV;
        } else {
            if (dark) {
                r = Math.min(255, pV + (C * 420)) | 0;
                g = Math.min(255, pV + (M * 420)) | 0;
                b = Math.min(255, pV + (Y * 420)) | 0;
            } else {
                r = (pV * Math.max(0, 1.0 - C * 1.15)) | 0;
                g = (pV * Math.max(0, 1.0 - M * 1.15)) | 0;
                b = (pV * Math.max(0, 1.0 - Y * 1.15)) | 0;
            }
            u32[i] = (255 << 24) | (b << 16) | (g << 8) | r;
        }
      }
      bCtx.putImageData(iData, 0, 0);
      ctx.imageSmoothingEnabled = false;
      const c = canvasRef.current;
      if (c) ctx.drawImage(bCanv, 0, 0, c.width, c.height);
      animationRef.current = requestAnimationFrame(render);
    };
    animationRef.current = requestAnimationFrame(render);
    return () => { if (animationRef.current) cancelAnimationFrame(animationRef.current); };
  }, [loading, paperParams.resolution]);

  const getSimPos = (e: any) => {
    if (!canvasRef.current || !simRef.current) return { x: 0, y: 0 };
    const rect = canvasRef.current.getBoundingClientRect();
    const cX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const cY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    return {
      x: (cX - rect.left) * (simRef.current.w / rect.width),
      y: (cY - rect.top) * (simRef.current.h / rect.height)
    };
  };

  const applyInput = (x: number, y: number, vx: number, vy: number) => {
    if (!simRef.current) return;
    const rgb = COLOR.toRGB(paramsRef.current.color);
    simRef.current.addInput(x, y, paramsRef.current.brushSize * (simRef.current.w / 256), paramsRef.current.waterAmount / 50, paramsRef.current.inkAmount / 20, rgb.r, rgb.g, rgb.b, vx, vy);
  };

  const onStart = (e: any) => { 
    if (isAutoPainting || isTracing) return;
    saveSnapshot(); isMouseDown.current = true; 
    lastPos.current = getSimPos(e); 
    applyInput(lastPos.current.x, lastPos.current.y, 0, 0); 
  };
  
  const onMove = (e: any) => {
    if (!isMouseDown.current || !lastPos.current || isAutoPainting || isTracing) return;
    const pos = getSimPos(e);
    applyInput(pos.x, pos.y, (pos.x - lastPos.current.x) * 0.5, (pos.y - lastPos.current.y) * 0.5);
    lastPos.current = pos;
  };

  return (
    <div className="w-full h-screen bg-[var(--bg-studio)] relative overflow-hidden flex flex-col items-center justify-center transition-all duration-500">
        <VoiceStatus liveState={liveState} toggleLive={() => liveState.isConnected ? liveClientRef.current?.disconnect() : liveClientRef.current?.connect()} />
        <div className={`flex items-center justify-center w-full h-full p-4 lg:p-8 transition-all duration-500 ${layoutMode === 'sidebar' ? 'pl-[440px]' : ''}`}>
            <div className="relative canvas-container max-w-[95vw] max-h-[85vh] aspect-square rounded-sm overflow-hidden shadow-2xl">
                {!loading && (
                    <canvas ref={canvasRef} width={1024} height={1024} className={`block w-full h-full cursor-crosshair transition-opacity duration-300 ${isTracing ? 'opacity-40' : 'opacity-100'}`} onMouseDown={onStart} onMouseMove={onMove} onMouseUp={() => isMouseDown.current = false} onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={() => isMouseDown.current = false} />
                )}
                
                {isTracing && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/10 backdrop-blur-md animate-in fade-in duration-500 z-50">
                    <div className="relative w-24 h-24 mb-6">
                        <div className="absolute inset-0 border-4 border-[var(--primary)] border-t-transparent rounded-full animate-spin"></div>
                        <div className="absolute inset-4 border-4 border-[var(--secondary)] border-b-transparent rounded-full animate-spin-reverse opacity-60"></div>
                        <div className="absolute inset-0 flex items-center justify-center">
                            <Sparkles size={24} className="text-[var(--primary)] animate-pulse" />
                        </div>
                    </div>
                    <div className="flex flex-col items-center gap-2">
                        <span className="text-[12px] font-black uppercase tracking-[0.4em] text-[var(--text-main)] drop-shadow-md">
                          MoXi Structural Engine
                        </span>
                        <div className="flex items-center gap-2 text-[10px] font-medium text-[var(--text-muted)] animate-pulse uppercase tracking-[0.2em]">
                            <Brain size={12} />
                            {traceStatus}
                        </div>
                    </div>
                  </div>
                )}

                <SettingsPill onClick={() => setIsSettingsMinimized(false)} isHidden={!isSettingsMinimized} aiOperation={currentAiOp} className="bottom-6 left-1/2 -translate-x-1/2" />
            </div>
        </div>
        <ControlPanel
            params={params} paperParams={paperParams} updateParams={handleUpdateParams} updatePaper={handleUpdatePaper}
            onClear={handleClear} onRegenPaper={() => simRef.current?.generatePaper(paperParams.type, paperParams.roughness, paperParams.contrast, paperParams.align)}
            onToggleView={handleToggleView} viewMode={viewMode} activeTab={activeTab} setActiveTab={setActiveTab}
            aiOperation={currentAiOp} onUndo={handleUndo} onRedo={() => {}} canUndo={undoStack.current.length > 0} canRedo={false}
            isMinimized={isSettingsMinimized} setIsMinimized={setIsSettingsMinimized} onSaveImage={handleSaveImage}
            layoutMode={layoutMode} setLayoutMode={setLayoutMode}
            onTraceImage={(base64) => handleAutoPaintImage(base64, true)}
            onAiStudioAction={handleAiStudioPrompt}
            detectedHarmony={detectedHarmony}
            isBusy={isTracing || isAutoPainting}
        />
        
        <style>{`
            @keyframes spin-reverse {
                from { transform: rotate(360deg); }
                to { transform: rotate(0deg); }
            }
            .animate-spin-reverse {
                animation: spin-reverse 1.5s linear infinite;
            }
        `}</style>
    </div>
  );
};
export default App;
