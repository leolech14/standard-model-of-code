
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { COLOR, OKLCH } from './colorEngine';
import { PaintingPlan, HarmonyAnalysis, HarmonyType } from '../types';

export interface Point {
  x: number;
  y: number;
  vx: number; 
  vy: number; 
  curvature: number; 
  pressure: number; 
  color: OKLCH;
}

export interface StrokeMetadata {
  isCurvy: boolean;
  totalLength: number;
  averageVelocity: number;
  vibrancy: number; 
  coverage: number; 
  startAngle: number;
  endAngle: number;
  dynamism: number; 
  saliency: number; 
  heartHarmonyScore: number; 
  harmonyScore: number; 
}

export interface Stroke {
  points: Point[];
  avgColor: OKLCH;
  priority: number;   
  thicknessMod: number;
  metadata: StrokeMetadata;
  brushConfig: {
    water: number;
    ink: number;
    size: number;
    viscosity: number;
  };
}

enum ColorRole {
  FOUNDATION = 'foundation',
  TRANSITION = 'transition',
  ACCENT = 'accent'
}

interface PaletteColor extends OKLCH {
  weight: number;
  role: ColorRole;
  isDominant: boolean;
}

export class ImageTracer {
  static async extractStrokes(base64: string, resolution: number, plan?: PaintingPlan): Promise<{ strokes: Stroke[], harmony: HarmonyAnalysis }> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = resolution;
        canvas.height = resolution;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) return reject('No context');

        const scale = Math.min(resolution / img.width, resolution / img.height);
        const x = (resolution - img.width * scale) / 2;
        const y = (resolution - img.height * scale) / 2;
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, resolution, resolution);
        ctx.drawImage(img, x, y, img.width * scale, img.height * scale);

        const imageData = ctx.getImageData(0, 0, resolution, resolution);
        const result = this.processImageData(imageData, resolution, resolution, plan);
        resolve(result);
      };
      img.onerror = reject;
      img.src = base64;
    });
  }

  private static processImageData(imageData: ImageData, w: number, h: number, plan?: PaintingPlan): { strokes: Stroke[], harmony: HarmonyAnalysis } {
    const data = imageData.data;
    const visited = new Uint8Array(w * h);
    const strokes: Stroke[] = [];
    
    const palette = this.extractPalette(data, 12); // Sample slightly more colors for better clustering
    const harmony = this.analyzeHarmony(palette);
    
    const foundationColors = palette.filter(p => p.role === ColorRole.FOUNDATION);
    const accentColors = palette.filter(p => p.role === ColorRole.ACCENT);

    const getColor = (x: number, y: number): OKLCH => {
      const i = (Math.floor(y) * w + Math.floor(x)) * 4;
      return this.rgbToOklch(data[i], data[i+1], data[i+2]);
    };

    const edges = new Float32Array(w * h);
    for (let y = 1; y < h-1; y++) {
      for (let x = 1; x < w-1; x++) {
        const i = y * w + x;
        const dx = (data[(i+1)*4] - data[(i-1)*4]);
        const dy = (data[(i+w)*4] - data[(i-w)*4]);
        edges[i] = Math.sqrt(dx*dx + dy*dy) / 255;
      }
    }

    const getPlanConfig = (priority: number) => {
        const instr = plan?.layerInstructions.find(li => li.priority === priority);
        return instr?.brushConfig;
    };

    // Stage 0: GESTURE (Lines and Structure)
    const gCfg = getPlanConfig(0);
    for (let y = 1; y < h-1; y += 4) {
      for (let x = 1; x < w-1; x += 4) {
        const i = y * w + x;
        const col = getColor(x, y);
        const isStructuralAccent = accentColors.some(p => (p.l < 0.3 || p.c > 0.18) && this.colorDistance(p, col) < 0.05);
        if ((edges[i] > 0.22 || isStructuralAccent) && !visited[i]) {
          const s = this.traceHumanPath(x, y, w, h, visited, getColor, 0.09, 200, palette, harmony);
          if (s.points.length > 5) {
            s.priority = 0;
            s.thicknessMod = 1.35 * (gCfg?.sizeMult || 1.0);
            s.brushConfig = { water: gCfg?.water ?? 35, ink: gCfg?.ink ?? 100, size: 8, viscosity: 45 };
            strokes.push(s);
          }
        }
      }
    }

    // Stage 1: FOUNDATION (Broad Wash)
    const fCfg = getPlanConfig(1);
    for (let y = 0; y < h; y += 15) {
      for (let x = 0; x < w; x += 15) {
        const i = y * w + x;
        const col = getColor(x, y);
        const isFoundation = foundationColors.some(p => this.colorDistance(p, col) < 0.15);
        if (isFoundation && col.l < 0.98 && !visited[i]) {
          const s = this.traceHumanPath(x, y, w, h, visited, getColor, 0.25, 500, palette, harmony);
          if (s.points.length > 15) {
            s.priority = 1;
            s.thicknessMod = 5.5 * (fCfg?.sizeMult || 1.0);
            s.brushConfig = { water: fCfg?.water ?? 98, ink: fCfg?.ink ?? 25, size: 24, viscosity: 8 };
            strokes.push(s);
          }
        }
      }
    }

    // Stage 2: FORM (Medium Detail)
    const formCfg = getPlanConfig(2);
    for (let y = 0; y < h; y += 7) {
      for (let x = 0; x < w; x += 7) {
        const i = y * w + x;
        const col = getColor(x, y);
        if (col.l < 0.99 && !visited[i]) {
          const s = this.traceHumanPath(x, y, w, h, visited, getColor, 0.14, 180, palette, harmony);
          if (s.points.length > 4) {
            s.priority = 2;
            s.thicknessMod = 1.15 * (formCfg?.sizeMult || 1.0);
            s.brushConfig = { water: formCfg?.water ?? 65, ink: formCfg?.ink ?? 85, size: 6.5, viscosity: 35 };
            strokes.push(s);
          }
        }
      }
    }

    // Stage 3: ACCENT (Highlights and Vibrant Details)
    const accCfg = getPlanConfig(3);
    for (let y = 0; y < h; y += 2) {
      for (let x = 0; x < w; x += 2) {
        const i = y * w + x;
        const col = getColor(x, y);
        const isHighVibrancy = col.c > 0.15;
        if ((isHighVibrancy || col.l < 0.25) && !visited[i]) {
          const s = this.traceHumanPath(x, y, w, h, visited, getColor, 0.04, 80, palette, harmony);
          if (s.points.length > 2) {
            s.priority = 3;
            s.thicknessMod = 0.65 * (accCfg?.sizeMult || 1.0);
            s.brushConfig = { water: accCfg?.water ?? 15, ink: accCfg?.ink ?? 100, size: 4, viscosity: 90 };
            strokes.push(s);
          }
        }
      }
    }

    return {
        strokes: strokes.sort((a, b) => {
            if (a.priority !== b.priority) return a.priority - b.priority;
            // Within same priority, sort by saliency and harmony
            const scoreA = a.metadata.saliency * (a.metadata.harmonyScore + 0.6);
            const scoreB = b.metadata.saliency * (b.metadata.harmonyScore + 0.6);
            return scoreB - scoreA;
        }),
        harmony
    };
  }

  private static traceHumanPath(sx: number, sy: number, w: number, h: number, visited: Uint8Array, getColor: any, tol: number, maxL: number, palette: PaletteColor[], harmony: HarmonyAnalysis): Stroke {
    const points: Point[] = [];
    let cx = sx, cy = sy;
    let sumL = 0, sumC = 0, sumH = 0;
    const startCol = getColor(sx, sy);
    let lastX = sx, lastY = sy;
    let runningVX = 0, runningVY = 0;
    let velocitySum = 0;
    let directionChanges = 0;
    let prevAngle = 0;

    while (points.length < maxL) {
      const idx = cy * w + cx;
      if (visited[idx]) break;
      visited[idx] = 1;
      const c = getColor(cx, cy);
      const rawVX = cx - lastX;
      const rawVY = cy - lastY;
      runningVX = runningVX * 0.72 + rawVX * 0.28;
      runningVY = runningVY * 0.72 + rawVY * 0.28;
      const speed = Math.sqrt(runningVX * runningVX + runningVY * runningVY);
      const currentAngle = Math.atan2(runningVY, runningVX);
      let curvature = 0;
      if (points.length > 1) {
          const diff = Math.abs(currentAngle - prevAngle);
          const angleDiff = Math.min(diff, Math.PI * 2 - diff);
          curvature = Math.min(1.0, angleDiff * 2.5);
          if (angleDiff > 0.15) directionChanges++;
      }
      points.push({ x: cx, y: cy, vx: runningVX, vy: runningVY, curvature, pressure: Math.pow(1.1 - c.l, 0.9), color: c });
      sumL += c.l; sumC += c.c; sumH += c.h; velocitySum += speed;
      prevAngle = currentAngle; lastX = cx; lastY = cy;
      let bestX = -1, bestY = -1, minDiff = tol;
      for (let dy = -2; dy <= 2; dy++) {
        for (let dx = -2; dx <= 2; dx++) {
          if (dx === 0 && dy === 0) continue;
          const nx = cx + dx, ny = cy + dy;
          if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
            const nIdx = ny * w + nx;
            if (!visited[nIdx]) {
              const nc = getColor(nx, ny);
              const diff = Math.abs(nc.l - startCol.l);
              if (diff < minDiff) { minDiff = diff; bestX = nx; bestY = ny; }
            }
          }
        }
      }
      if (bestX === -1) break;
      cx = bestX; cy = bestY;
    }
    const n = points.length || 1;
    const avgChroma = sumC / n;
    const avgLightness = sumL / n;
    const avgColor = { l: avgLightness, c: avgChroma, h: sumH / n };
    
    // --- HARMONY SCORE CALCULATION ---
    const nearestDist = Math.min(...palette.map(p => this.colorDistance(p, avgColor)));
    let harmonyScore = Math.max(0, 1.0 - nearestDist * 4.0);

    const checkHueMatch = (h1: number, h2: number) => {
        const diff = Math.abs(h1 - h2);
        return Math.min(diff, 360 - diff);
    };

    const distToPrimary = checkHueMatch(harmony.primaryHue, avgColor.h);
    const isHighChroma = avgChroma > 0.12;

    // Weighting based on scheme type
    switch (harmony.type) {
        case HarmonyType.MONOCHROMATIC:
            // Score primarily based on hue closeness to primary
            if (distToPrimary < 25) harmonyScore += 0.5;
            break;
            
        case HarmonyType.ANALOGOUS:
            // High score if it falls within the 60 deg arc of primary
            if (distToPrimary < 45) harmonyScore += 0.4;
            for (const sh of harmony.supportHues) {
                if (checkHueMatch(sh, avgColor.h) < 25) harmonyScore += 0.3;
            }
            break;
            
        case HarmonyType.COMPLEMENTARY:
            if (distToPrimary < 20) harmonyScore += 0.3;
            const complement = (harmony.primaryHue + 180) % 360;
            const distToComp = checkHueMatch(complement, avgColor.h);
            if (distToComp < 25) {
                // Large boost for complementary accent colors
                harmonyScore += 0.6 + (isHighChroma ? avgChroma * 2.5 : 0);
            }
            break;
            
        case HarmonyType.TRIADIC:
        case HarmonyType.SPLIT_COMPLEMENTARY:
            if (distToPrimary < 20) harmonyScore += 0.3;
            for (const sh of harmony.supportHues) {
                const distToSupp = checkHueMatch(sh, avgColor.h);
                if (distToSupp < 25) {
                    // Support hues are usually the "pop" colors in these schemes
                    harmonyScore += 0.5 + (isHighChroma ? avgChroma * 2.0 : 0);
                }
            }
            break;
            
        default:
            // Diverse or unknown: fallback to general matching
            if (distToPrimary < 20) harmonyScore += 0.2;
            for (const sh of harmony.supportHues) {
                if (checkHueMatch(sh, avgColor.h) < 20) harmonyScore += 0.3;
            }
            break;
    }

    const metadata: StrokeMetadata = {
      isCurvy: n / (Math.sqrt(Math.pow(points[n-1].x - points[0].x, 2) + Math.pow(points[n-1].y - points[0].y, 2)) + 0.001) > 1.35,
      totalLength: n,
      averageVelocity: velocitySum / n,
      vibrancy: Math.min(1.0, avgChroma * 3.5 * harmony.vibrancyScale),
      coverage: (n * 5.0) / (w * h),
      startAngle: Math.atan2(points[Math.min(2, n-1)].y - points[0].y, points[Math.min(2, n-1)].x - points[0].x),
      endAngle: Math.atan2(points[n-1].y - points[Math.max(0, n-3)].y, points[n-1].x - points[Math.max(0, n-3)].x),
      dynamism: Math.min(1.0, (directionChanges / n) * 15),
      saliency: (1.1 - avgLightness) * (1.1 + avgChroma * 3.2),
      heartHarmonyScore: Math.min(1.0, harmonyScore),
      harmonyScore: Math.min(1.0, harmonyScore)
    };
    return { points, priority: 1, thicknessMod: 1, avgColor, metadata, brushConfig: { water: 75, ink: 65, size: 6, viscosity: 25 } };
  }

  private static analyzeHarmony(palette: PaletteColor[]): HarmonyAnalysis {
    if (palette.length === 0) return { type: HarmonyType.DIVERSE, primaryHue: 0, supportHues: [], vibrancyScale: 1.0 };
    
    // Primary hue is typically the dominant foundation color
    const dominant = palette.find(p => p.role === ColorRole.FOUNDATION) || palette[0];
    const primaryHue = dominant.h;
    
    const hues = palette.map(p => p.h);
    const chromas = palette.map(p => p.c);
    const avgChroma = chromas.reduce((a, b) => a + b, 0) / palette.length;
    const chromaRange = Math.max(...chromas) - Math.min(...chromas);

    // 1. Monochromatic check: Very low average chroma or hue spread
    if (chromaRange < 0.08 || avgChroma < 0.07) {
        return { type: HarmonyType.MONOCHROMATIC, primaryHue, supportHues: [], vibrancyScale: 0.8 };
    }

    const hueMatch = (h1: number, h2: number) => {
        const diff = Math.abs(h1 - h2);
        return Math.min(diff, 360 - diff);
    };

    // Filter for "active" hues (ignore neutrals)
    const activePalette = palette.filter(p => p.c > 0.08);
    const activeHues = activePalette.map(p => h => h); // Placeholder to make TypeScript happy or just use map below
    const huesToAnalyze = activePalette.map(p => p.h);

    if (huesToAnalyze.length < 2) {
        return { type: HarmonyType.MONOCHROMATIC, primaryHue, supportHues: [], vibrancyScale: 0.8 };
    }

    // 2. Analogous check: Most active hues within a 90-degree wedge
    const isAnalogous = huesToAnalyze.every(h => hueMatch(h, primaryHue) < 50);
    if (isAnalogous) {
        const support = activePalette.filter(p => p !== dominant).map(p => p.h).slice(0, 2);
        return { type: HarmonyType.ANALOGOUS, primaryHue, supportHues: support, vibrancyScale: 1.1 };
    }

    // 3. Search for contrasting schemes
    let complement: number | null = null;
    let splitComps: number[] = [];
    let triads: number[] = [];

    for (const p of activePalette) {
        if (p === dominant) continue;
        const dist = hueMatch(p.h, primaryHue);
        
        if (dist > 165) complement = p.h;
        if (dist > 135 && dist < 165) splitComps.push(p.h);
        if (dist > 100 && dist < 140) triads.push(p.h);
    }

    if (complement !== null) {
        return { type: HarmonyType.COMPLEMENTARY, primaryHue, supportHues: [complement], vibrancyScale: 1.4 };
    }
    
    if (splitComps.length >= 1) {
        return { type: HarmonyType.SPLIT_COMPLEMENTARY, primaryHue, supportHues: splitComps.slice(0, 2), vibrancyScale: 1.3 };
    }

    if (triads.length >= 1) {
        return { type: HarmonyType.TRIADIC, primaryHue, supportHues: triads.slice(0, 2), vibrancyScale: 1.25 };
    }

    return { type: HarmonyType.DIVERSE, primaryHue, supportHues: huesToAnalyze.filter(h => h !== primaryHue).slice(0, 2), vibrancyScale: 1.0 };
  }

  private static extractPalette(data: Uint8ClampedArray, maxCount: number): PaletteColor[] {
    const numSamples = 8000;
    const samples: { L: number, a: number, b: number }[] = [];
    const step = Math.max(1, Math.floor(data.length / (4 * numSamples)));
    for (let i = 0; i < data.length; i += 4 * step) {
      if (samples.length >= numSamples) break;
      const r = data[i]/255, g = data[i+1]/255, b = data[i+2]/255;
      const lin = (v: number) => v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
      const lr = lin(r), lg = lin(g), lb = lin(b);
      const l_ = 0.4122 * lr + 0.5363 * lg + 0.0514 * lb;
      const m_ = 0.2119 * lr + 0.6807 * lg + 0.1074 * lb;
      const s_ = 0.0883 * lr + 0.2817 * lg + 0.6300 * lb;
      const l_c = Math.pow(l_, 1/3), m_c = Math.pow(m_, 1/3), s_c = Math.pow(s_, 1/3);
      samples.push({ L: 0.2104 * l_c + 0.7936 * m_c - 0.0040 * s_c, a: 1.9779 * l_c - 2.4285 * m_c + 0.4505 * s_c, b: 0.0259 * l_c + 0.7827 * m_c - 0.8086 * s_c });
    }
    if (samples.length === 0) return [];
    
    // K-Means Clustering
    let centroids: { L: number, a: number, b: number, weight: number }[] = [];
    centroids.push({ ...samples[Math.floor(Math.random() * samples.length)], weight: 0 });
    for (let k = 1; k < maxCount; k++) {
      let maxDist = -1, bestIdx = 0;
      for (let i = 0; i < samples.length; i++) {
        let minDist = Infinity;
        for (const c of centroids) {
          const dL = samples[i].L - c.L, da = samples[i].a - c.a, db = samples[i].b - c.b;
          const d = dL*dL + da*da + db*db;
          if (d < minDist) minDist = d;
        }
        if (minDist > maxDist) { maxDist = minDist; bestIdx = i; }
      }
      centroids.push({ ...samples[bestIdx], weight: 0 });
    }

    for (let iter = 0; iter < 18; iter++) {
        const clusters = Array.from({ length: centroids.length }, () => ({ L: 0, a: 0, b: 0, count: 0 }));
        for (const s of samples) {
            let minDist = Infinity, bestK = 0;
            for (let k = 0; k < centroids.length; k++) {
                const dL = s.L - centroids[k].L, da = s.a - centroids[k].a, db = s.b - centroids[k].b;
                const d = dL*dL + da*da + db*db;
                if (d < minDist) { minDist = d; bestK = k; }
            }
            clusters[bestK].L += s.L; clusters[bestK].a += s.a; clusters[bestK].b += s.b; clusters[bestK].count++;
        }
        for (let k = 0; k < centroids.length; k++) {
            if (clusters[k].count > 0) {
                centroids[k].L = clusters[k].L / clusters[k].count;
                centroids[k].a = clusters[k].a / clusters[k].count;
                centroids[k].b = clusters[k].b / clusters[k].count;
                centroids[k].weight = clusters[k].count / samples.length;
            }
        }
    }

    // Perceptual Grouping & Role Assignment
    const rawPalette: {L: number, a: number, b: number, weight: number}[] = [];
    const used = new Set<number>();
    for (let i = 0; i < centroids.length; i++) {
      if (used.has(i)) continue;
      let mergedL = centroids[i].L * centroids[i].weight;
      let mergedA = centroids[i].a * centroids[i].weight;
      let mergedB = centroids[i].b * centroids[i].weight;
      let totalW = centroids[i].weight;
      for (let j = i + 1; j < centroids.length; j++) {
        if (used.has(j)) continue;
        const dL = centroids[i].L - centroids[j].L;
        const da = centroids[i].a - centroids[j].a;
        const db = centroids[i].b - centroids[j].b;
        if (Math.sqrt(dL*dL + da*da + db*db) < 0.05) {
          mergedL += centroids[j].L * centroids[j].weight; mergedA += centroids[j].a * centroids[j].weight; mergedB += centroids[j].b * centroids[j].weight;
          totalW += centroids[j].weight; used.add(j);
        }
      }
      rawPalette.push({ L: mergedL / totalW, a: mergedA / totalW, b: mergedB / totalW, weight: totalW });
    }

    // Calculate Palette Statistics
    const avgL = rawPalette.reduce((sum, c) => sum + c.L * c.weight, 0) / rawPalette.reduce((sum, c) => sum + c.weight, 0);
    const avgC = rawPalette.reduce((sum, c) => {
        const chroma = Math.sqrt(c.a * c.a + c.b * c.b);
        return sum + chroma * c.weight;
    }, 0) / rawPalette.reduce((sum, c) => sum + c.weight, 0);

    const resultPalette: PaletteColor[] = rawPalette.map(c => {
        const chroma = Math.sqrt(c.a * c.a + c.b * c.b);
        const hue = (Math.atan2(c.b, c.a) * 180 / Math.PI + 360) % 360;
        
        let role = ColorRole.TRANSITION;
        const isHighContrast = Math.abs(c.L - avgL) > 0.3;
        const isHighlySaturated = chroma > 0.2 || (chroma > avgC * 2.2 && chroma > 0.1);
        const isExtremeValue = c.L < 0.22 || c.L > 0.88;

        if (c.weight > 0.18 && chroma < 0.14) {
            role = ColorRole.FOUNDATION;
        } 
        else if (isHighlySaturated || isHighContrast || (c.weight < 0.1 && (isExtremeValue || chroma > 0.12))) {
            role = ColorRole.ACCENT;
        }

        return { l: c.L, c: chroma, h: hue, weight: c.weight, role, isDominant: c.weight > 0.22 };
    });

    return resultPalette.sort((a, b) => b.weight - a.weight);
  }

  private static rgbToOklch(r: number, g: number, b: number): OKLCH {
    r /= 255; g /= 255; b /= 255;
    const lin = (v: number) => v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    const lr = lin(r), lg = lin(g), lb = lin(b);
    const l = 0.4122 * lr + 0.5363 * lg + 0.0514 * lb;
    const m = 0.2119 * lr + 0.6807 * lg + 0.1074 * lb;
    const s = 0.0883 * lr + 0.2817 * lg + 0.6300 * lb;
    const l_ = Math.pow(l, 1/3), m_ = Math.pow(m, 1/3), s_ = Math.pow(s, 1/3);
    const L = 0.2104 * l_ + 0.7936 * m_ - 0.0040 * s_;
    const a = 1.9779 * l_ - 2.4285 * m_ + 0.4505 * s_;
    const b_ = 0.0259 * l_ + 0.7827 * m_ - 0.8086 * s_;
    return { l: L, c: Math.sqrt(a*a + b_*b_), h: (Math.atan2(b_, a) * 180 / Math.PI + 360) % 360 };
  }

  private static colorDistance(c1: OKLCH, c2: OKLCH): number {
    const dL = c1.l - c2.l;
    const dC = c1.c - c2.c;
    const dh = Math.min(Math.abs(c1.h - c2.h), 360 - Math.abs(c1.h - c2.h)) / 360;
    return Math.sqrt(dL*dL * 0.75 + dC*dC * 1.8 + dh*dh * 2.5);
  }
}
