
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { GoogleGenAI, LiveServerMessage, Modality, Type, FunctionDeclaration, GenerateContentResponse } from '@google/genai';
import { ToolHandler, PaintingPlan, AspectRatio } from '../types';

const MODEL_LIVE = 'gemini-2.5-flash-native-audio-preview-12-2025';
const MODEL_PRO = 'gemini-3-pro-preview';
const MODEL_FAST = 'gemini-2.5-flash-lite-latest';
const MODEL_IMAGE = 'gemini-3-pro-image-preview';

const tools: FunctionDeclaration[] = [
  {
    name: 'updateSimulation',
    description: 'Adjust simulation physics and brush parameters.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        brushSize: { type: Type.NUMBER, description: 'Brush radius (1-40)' },
        waterAmount: { type: Type.NUMBER, description: 'Water amount (0-100)' },
        inkAmount: { type: Type.NUMBER, description: 'Ink amount (0-100)' },
        dryingSpeed: { type: Type.NUMBER, description: 'Drying speed (0-100)' },
        viscosity: { type: Type.NUMBER, description: 'Fluid viscosity (0-100)' },
        brushType: { type: Type.STRING, description: 'Type of brush: round, flat, sumi, spray, water' }
      }
    }
  },
  {
    name: 'updatePaper',
    description: 'Change paper texture, resolution, and properties.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        type: { type: Type.STRING, description: 'Paper type: rice, canvas, watercolor, smooth' },
        roughness: { type: Type.NUMBER, description: 'Paper roughness (0-100)' },
        contrast: { type: Type.NUMBER, description: 'Texture contrast (0-100)' },
        resolution: { type: Type.INTEGER, description: 'Simulation grid resolution: 256, 512, or 1024' }
      }
    }
  },
  {
    name: 'setColor',
    description: 'Set the current ink color using perceptually uniform OKLCH values.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        l: { type: Type.NUMBER, description: 'Lightness (0.0 - 1.0). 0 is black, 1 is white.' },
        c: { type: Type.NUMBER, description: 'Chroma (0.0 - 0.4). 0 is gray, 0.4 is very vivid.' },
        h: { type: Type.NUMBER, description: 'Hue (0.0 - 360.0). Blue ~ 240, Red ~ 0, Green ~ 140.' }
      },
      required: ['l', 'c', 'h']
    }
  },
  {
    name: 'switchTab',
    description: 'Switch the visible UI tab.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        tab: { type: Type.STRING, description: 'Tab name: paint, brushes, physics, paper, studio' }
      },
      required: ['tab']
    }
  },
  {
    name: 'controlApp',
    description: 'Perform general app actions like clearing the canvas, undoing the last stroke, or redoing.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        action: { type: Type.STRING, description: 'Action to perform: clear, regenerate, toggleView, undo, redo' }
      },
      required: ['action']
    }
  }
];

export class LiveClient {
  private ai: GoogleGenAI;
  private audioContext: AudioContext | null = null;
  private inputAudioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private inputSource: MediaStreamAudioSourceNode | null = null;
  private processor: ScriptProcessorNode | null = null;
  private nextStartTime = 0;
  private sources = new Set<AudioBufferSourceNode>();
  private toolHandler: ToolHandler;
  private onStatusChange: (status: { isConnected: boolean; isSpeaking: boolean; error: string | null }) => void;
  private session: any = null;

  constructor(apiKey: string, toolHandler: ToolHandler, onStatusChange: any) {
    this.ai = new GoogleGenAI({ apiKey });
    this.toolHandler = toolHandler;
    this.onStatusChange = onStatusChange;
  }

  async connect() {
    try {
      this.onStatusChange({ isConnected: true, isSpeaking: false, error: null });
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.inputSource = this.inputAudioContext.createMediaStreamSource(this.mediaStream);
      this.processor = this.inputAudioContext.createScriptProcessor(4096, 1, 1);

      const sessionPromise = this.ai.live.connect({
        model: MODEL_LIVE,
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: `You are MoXi, an expert digital ink assistant.
          You help users manage a complex fluid physics ink simulation.
          You can adjust simulation parameters, switch colors using OKLCH, and change paper types.`,
          tools: [{ functionDeclarations: tools }]
        },
        callbacks: {
            onopen: () => {
                if (this.processor && this.inputSource && this.inputAudioContext) {
                    this.processor.onaudioprocess = (e) => {
                        const inputData = e.inputBuffer.getChannelData(0);
                        const pcmBlob = this.createPcmBlob(inputData);
                        sessionPromise.then(session => {
                            if (session) session.sendRealtimeInput({ media: pcmBlob });
                        });
                    };
                    this.inputSource.connect(this.processor);
                    this.processor.connect(this.inputAudioContext.destination);
                }
            },
            onmessage: async (msg: LiveServerMessage) => {
                const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                if (audioData) {
                    this.onStatusChange({ isConnected: true, isSpeaking: true, error: null });
                    await this.playAudio(audioData);
                } else if (msg.serverContent?.turnComplete) {
                    this.onStatusChange({ isConnected: true, isSpeaking: false, error: null });
                }
                if (msg.toolCall) {
                    this.handleToolCalls(msg.toolCall, sessionPromise);
                }
            },
            onclose: () => this.disconnect(),
            onerror: (err) => {
                this.onStatusChange({ isConnected: false, isSpeaking: false, error: "Connection Error" });
                this.disconnect();
            }
        }
      });
      this.session = sessionPromise;
    } catch (e: any) {
      this.onStatusChange({ isConnected: false, isSpeaking: false, error: e.message });
      this.disconnect();
    }
  }

  async handleToolCalls(toolCall: any, sessionPromise: Promise<any>) {
    for (const fc of toolCall.functionCalls) {
        let result: any = { result: "ok" };
        try {
            switch (fc.name) {
                case 'updateSimulation': this.toolHandler.updateSimulation(fc.args); break;
                case 'updatePaper': this.toolHandler.updatePaper(fc.args); break;
                case 'setColor': this.toolHandler.setColor(fc.args.l, fc.args.c, fc.args.h); break;
                case 'switchTab': this.toolHandler.switchTab(fc.args.tab); break;
                case 'controlApp': this.toolHandler.controlApp(fc.args.action); break;
            }
        } catch (e) { result = { result: "failed" }; }
        const session = await sessionPromise;
        if (session) {
          session.sendToolResponse({ functionResponses: { id: fc.id, name: fc.name, response: result } });
        }
    }
  }

  /**
   * Fast Intelligence: gemini-2.5-flash-lite for low latency responses.
   */
  async fastQuery(prompt: string): Promise<string> {
    const response = await this.ai.models.generateContent({
      model: MODEL_FAST,
      contents: [{ parts: [{ text: prompt }] }]
    });
    return response.text || '';
  }

  /**
   * Complex Intelligence: gemini-3-pro-preview with thinkingBudget for deep analysis.
   */
  async think(prompt: string): Promise<string> {
    const response = await this.ai.models.generateContent({
      model: MODEL_PRO,
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        thinkingConfig: { thinkingBudget: 32768 }
      }
    });
    return response.text || '';
  }

  /**
   * Vision Trace: gemini-3-pro-preview for image understanding and strategy.
   */
  async analyzeExternalImage(base64: string): Promise<PaintingPlan> {
    const response = await this.ai.models.generateContent({
      model: MODEL_PRO,
      contents: [
        { inlineData: { data: base64, mimeType: 'image/jpeg' } },
        { text: `Analyze this image as an art director. Create a detailed 'PaintingPlan' in JSON format for a fluid ink simulation.
        Respond ONLY with JSON matching:
        interface PaintingPlan {
          style: 'watercolor' | 'sumi-e' | 'abstract' | 'impasto';
          harmony: string;
          layerInstructions: {
            priority: number; // 0: Gesture, 1: Foundation, 2: Form, 3: Accent
            label: string;
            brushConfig: { water: number; ink: number; sizeMult: number; };
          }[];
        }` }
      ],
      config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '{}');
  }

  /**
   * Image Generation: gemini-3-pro-image-preview with aspect ratio control.
   */
  async generateImage(prompt: string, aspectRatio: AspectRatio): Promise<string> {
    const response = await this.ai.models.generateContent({
      model: MODEL_IMAGE,
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        imageConfig: {
          aspectRatio: aspectRatio
        }
      }
    });
    
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error('No image generated');
  }

  createPcmBlob(data: Float32Array) {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) int16[i] = data[i] * 32768;
    const bytes = new Uint8Array(int16.buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return { mimeType: 'audio/pcm;rate=16000', data: btoa(binary) };
  }

  async playAudio(base64Data: string) {
    if (!this.audioContext) return;
    const binaryString = atob(base64Data);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    const dataInt16 = new Int16Array(bytes.buffer);
    const buffer = this.audioContext.createBuffer(1, dataInt16.length, 24000);
    const channelData = buffer.getChannelData(0);
    for(let i=0; i<dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
    const source = this.audioContext.createBufferSource();
    source.buffer = buffer;
    source.connect(this.audioContext.destination);
    this.nextStartTime = Math.max(this.nextStartTime, this.audioContext.currentTime);
    source.start(this.nextStartTime);
    this.nextStartTime += buffer.duration;
    this.sources.add(source);
    source.onended = () => {
        this.sources.delete(source);
        if (this.sources.size === 0) this.onStatusChange({ isConnected: true, isSpeaking: false, error: null });
    };
  }

  disconnect() {
    if (this.session) { this.session.then((s: any) => { try { s?.close(); } catch(e) {} }); this.session = null; }
    if (this.mediaStream) { this.mediaStream.getTracks().forEach(track => track.stop()); this.mediaStream = null; }
    this.sources.forEach(s => { try { s.stop(); } catch(e){} });
    this.sources.clear();
    if (this.processor) { this.processor.onaudioprocess = null; this.processor.disconnect(); }
    this.inputSource?.disconnect();
    this.processor = null;
    this.inputSource = null;
    if (this.audioContext?.state !== 'closed') this.audioContext?.close();
    this.audioContext = null;
    if (this.inputAudioContext?.state !== 'closed') this.inputAudioContext?.close();
    this.inputAudioContext = null;
    this.onStatusChange({ isConnected: false, isSpeaking: false, error: null });
  }
}
