
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export interface OKLCH {
  l: number; // 0 to 1
  c: number; // 0 to 0.4
  h: number; // 0 to 360
}

export interface RGB {
  r: number;
  g: number;
  b: number;
}

class ColorEngine {
  private transforms = {
    hueShift: 0,
    chromaScale: 1.0,
    lightnessShift: 0
  };

  private palettes: Record<string, Record<string, OKLCH>> = {
    tier: {
      'T0': { l: 0.68, c: 0.20, h: 142 },
      'T1': { l: 0.65, c: 0.11, h: 220 },
      'T2': { l: 0.68, c: 0.20, h: 330 },
    },
    family: {
      'LOG': { l: 0.62, c: 0.11, h: 220 },
      'DAT': { l: 0.68, c: 0.20, h: 142 },
      'ORG': { l: 0.60, c: 0.18, h: 280 },
      'CFG': { l: 0.70, c: 0.22, h: 45 },
      'AST': { l: 0.65, c: 0.25, h: 320 },
    }
  };

  getRaw(dimension: string, category: string): OKLCH {
    return this.palettes[dimension]?.[category] || { l: 0.5, c: 0, h: 0 };
  }

  toRGB(color: OKLCH): RGB {
    const L = Math.max(0, Math.min(1, color.l + this.transforms.lightnessShift / 100));
    const C = Math.max(0, Math.min(0.4, color.c * this.transforms.chromaScale));
    const hRad = ((color.h + this.transforms.hueShift) * Math.PI) / 180;

    const a = Math.cos(hRad) * C;
    const b = Math.sin(hRad) * C;

    // OKLab -> Linear sRGB (D65)
    const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
    const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
    const s_ = L - 0.0894841775 * a - 1.2914855480 * b;

    const l = l_ * l_ * l_;
    const m = m_ * m_ * m_;
    const s = s_ * s_ * s_;

    let r = +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
    let g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
    let bl = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s;

    // Linear -> sRGB Gamma
    const f = (v: number) => (v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055);

    return {
      r: Math.round(Math.max(0, Math.min(255, f(r) * 255))),
      g: Math.round(Math.max(0, Math.min(255, f(g) * 255))),
      b: Math.round(Math.max(0, Math.min(255, f(bl) * 255))),
    };
  }

  toHex(color: OKLCH): string {
    const rgb = this.toRGB(color);
    return `#${((1 << 24) + (rgb.r << 16) + (rgb.g << 8) + rgb.b).toString(16).slice(1)}`;
  }
}

export const COLOR = new ColorEngine();
