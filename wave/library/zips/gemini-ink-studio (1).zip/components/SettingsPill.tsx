
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { Sliders, Paintbrush, Droplets, Trash2, Eye, RefreshCw, Palette, Brain, Sparkles, Image as ImageIcon } from 'lucide-react';
import { AIOperationState } from '../types';

interface SettingsPillProps {
  onClick: () => void;
  isHidden: boolean;
  aiOperation: AIOperationState | null;
  className?: string;
}

const getIcon = (iconName?: string) => {
  switch(iconName) {
      case 'brush': return <Paintbrush size={18} />;
      case 'water': return <Droplets size={18} />;
      case 'settings': return <Sliders size={18} />;
      case 'trash': return <Trash2 size={18} />;
      case 'eye': return <Eye size={18} />;
      case 'refresh': return <RefreshCw size={18} />;
      case 'physics': return <Sliders size={18} />;
      case 'palette': return <Palette size={18} />;
      case 'brain': return <Brain size={18} />;
      case 'spark': return <Sparkles size={18} />;
      case 'image': return <ImageIcon size={18} />;
      default: return <Sliders size={18} />;
  }
};

const ThinkingAnimation = () => (
    <div className="flex items-center gap-1">
        {[0, 1, 2].map(i => (
            <div 
              key={i} 
              className="w-1.5 h-1.5 bg-[var(--primary)] rounded-full animate-bounce" 
              style={{ animationDelay: `${i * 0.1}s` }}
            ></div>
        ))}
    </div>
);

const AnimatedSliderDisplay = ({ value, min, max }: { value: number, min: number, max: number }) => {
    const [width, setWidth] = useState(0);
    const [displayValue, setDisplayValue] = useState(min);

    useEffect(() => {
        const targetWidth = Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100));
        const timer = setTimeout(() => setWidth(targetWidth), 50);

        let startTimestamp: number | null = null;
        const duration = 800;
        const startValue = min; 
        
        const step = (timestamp: number) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            
            const current = startValue + (value - startValue) * easeOut;
            setDisplayValue(current);
            
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        const animFrame = window.requestAnimationFrame(step);

        return () => {
            clearTimeout(timer);
            window.cancelAnimationFrame(animFrame);
        };
    }, [value, min, max]);

    return (
        <div className="flex items-center gap-3 w-full h-4">
            <div className="relative flex-1 h-1.5 bg-[var(--bg-studio)] rounded-full overflow-hidden">
                <div 
                    className="absolute top-0 left-0 h-full bg-[var(--primary)] transition-all duration-1000 ease-out"
                    style={{ width: `${width}%` }}
                ></div>
            </div>
            <span className="text-[9px] font-black text-[var(--text-main)] w-6 text-right opacity-60">
                {Math.round(displayValue)}
            </span>
        </div>
    );
};

export const SettingsPill: React.FC<SettingsPillProps> = ({ onClick, isHidden, aiOperation, className = '' }) => {
  return (
    <button
      onClick={onClick}
      className={`absolute z-40 bg-white shadow-2xl border border-white text-[var(--text-main)] rounded-full flex items-center justify-center transition-perceptual active:scale-95
        ${className}
        ${isHidden ? 'opacity-0 translate-y-12 pointer-events-none' : 'opacity-100 translate-y-0 pointer-events-auto'} 
        ${aiOperation ? 'w-[320px] px-5 h-14' : 'w-[160px] px-8 h-14 hover:scale-105 hover:shadow-[var(--shadow-color)]'}`}
    >
      <div className={`absolute flex items-center gap-3 transition-perceptual ${aiOperation ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
           <Sliders size={20} className="text-[var(--primary)]" />
           <span className="text-[10px] font-black uppercase tracking-[0.2em]">Settings</span>
      </div>

      {aiOperation && (
          <div 
              key={`${aiOperation.label}-${aiOperation.value}`}
              className="w-full flex items-center gap-4 animate-in fade-in slide-in-from-left-4 duration-500"
          >
              <div className={`text-[var(--primary)] bg-[var(--primary-soft)] p-2.5 rounded-2xl flex-shrink-0 shadow-sm border border-[var(--primary)]/10 ${aiOperation.type === 'thinking' ? 'animate-pulse' : ''}`}>
                  {getIcon(aiOperation.icon)}
              </div>
              
              <div className="flex-1 flex flex-col justify-center gap-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <span className={`text-[9px] uppercase font-black text-[var(--text-muted)] tracking-[0.15em] leading-none ${aiOperation.type === 'action' || aiOperation.type === 'thinking' ? 'text-[10px] text-[var(--text-main)]' : ''}`}>
                        {aiOperation.label}
                    </span>
                    {aiOperation.type === 'thinking' && <ThinkingAnimation />}
                  </div>
                  
                  {aiOperation.type === 'slider' && typeof aiOperation.value === 'number' && (
                      <AnimatedSliderDisplay 
                          value={aiOperation.value} 
                          min={aiOperation.min || 0} 
                          max={aiOperation.max || 100} 
                      />
                  )}

                  {aiOperation.type === 'color' && typeof aiOperation.value === 'string' && (
                      <div className="w-full h-2 rounded-full bg-[var(--bg-studio)] overflow-hidden border border-[var(--border-subtle)]">
                           <div 
                              className="h-full w-full transition-colors duration-1000" 
                              style={{ backgroundColor: aiOperation.value }}
                           ></div>
                      </div>
                  )}
              </div>
          </div>
      )}
    </button>
  );
};
