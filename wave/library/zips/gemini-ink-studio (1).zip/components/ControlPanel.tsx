
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useState, useEffect } from 'react';
import { Sliders, Paintbrush, FileText, Droplets, Trash2, Eye, RefreshCw, ChevronDown, Undo2, Redo2, Image as ImageIcon, Sun, Moon, Maximize2, Columns, ScanSearch, Hash, Brain, Sparkles, Wand2, Zap, Loader2 } from 'lucide-react';
import { SimulationParams, PaperParams, BrushType, PaperType, AIOperationState, HarmonyAnalysis, AspectRatio } from '../types';
import { COLOR } from '../services/colorEngine';

interface RangeProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (val: number) => void;
  gradient?: string;
  suffix?: string;
}

const Range: React.FC<RangeProps> = ({ label, value, min, max, step, onChange, gradient, suffix = "" }) => (
  <div className="flex flex-col gap-1 w-full">
    <div className="flex justify-between items-center mb-0.5">
      <label className="text-[10px] uppercase font-bold tracking-wider text-[var(--text-muted)]">{label}</label>
      <span className="text-[10px] font-mono text-[var(--text-muted)] opacity-60">{value.toFixed(step === 1 ? 0 : 2)}{suffix}</span>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(parseFloat(e.target.value))}
      className="w-full h-1 rounded-full cursor-pointer focus:outline-none focus:ring-2 focus:ring-[var(--primary)]/20 touch-none transition-colors duration-500"
      style={gradient ? { background: gradient } : { backgroundColor: 'var(--border-subtle)' }}
    />
  </div>
);

interface TabButtonProps {
  id: string;
  activeTab: string;
  setActiveTab: (tab: any) => void;
  icon: any;
  label: string;
}

const TabButton: React.FC<TabButtonProps> = ({ id, activeTab, setActiveTab, icon: Icon, label }) => (
  <button
    onClick={() => setActiveTab(id)}
    className={`flex-1 flex flex-col items-center justify-center py-4 text-[9px] font-black uppercase tracking-widest transition-perceptual ${
      activeTab === id 
        ? 'text-[var(--primary)] bg-[var(--bg-card)] border-b-2 border-[var(--primary)]' 
        : 'text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-studio)]/40'
    }`}
  >
    <Icon size={16} className="mb-1" />
    {label}
  </button>
);

const HarmonyMatrix: React.FC<{ harmony: HarmonyAnalysis, onSelectHue: (h: number) => void }> = ({ harmony, onSelectHue }) => {
    return (
        <div className="bg-[var(--primary-soft)]/20 border border-[var(--primary)]/10 rounded-3xl p-6 space-y-4 animate-in fade-in zoom-in-95 duration-700">
            <div className="flex justify-between items-center">
                <div className="flex flex-col">
                    <span className="text-[8px] font-black uppercase tracking-[0.25em] text-[var(--primary)] mb-1">Detected Chord</span>
                    <span className="text-[11px] font-black uppercase tracking-[0.1em] text-[var(--text-main)]">{harmony.type.replace('_', ' ')}</span>
                </div>
                <Hash size={14} className="text-[var(--primary)] opacity-40" />
            </div>
            
            <div className="flex items-center gap-3">
                <button 
                    onClick={() => onSelectHue(harmony.primaryHue)}
                    className="group relative flex flex-col items-center gap-2"
                >
                    <div 
                        className="w-10 h-10 rounded-full border-2 border-white shadow-lg group-hover:scale-110 transition-transform" 
                        style={{ backgroundColor: COLOR.toHex({ l: 0.6, c: 0.15, h: harmony.primaryHue }) }}
                    />
                    <span className="text-[7px] font-bold text-[var(--text-muted)] group-hover:text-[var(--primary)]">PRIMARY</span>
                </button>

                {harmony.supportHues.map((h, i) => (
                    <button 
                        key={i} 
                        onClick={() => onSelectHue(h)}
                        className="group relative flex flex-col items-center gap-2"
                    >
                        <div 
                            className="w-8 h-8 rounded-full border border-white shadow-md group-hover:scale-110 transition-transform" 
                            style={{ backgroundColor: COLOR.toHex({ l: 0.6, c: 0.15, h: h }) }}
                        />
                        <span className="text-[7px] font-bold text-[var(--text-muted)] group-hover:text-[var(--primary)]">SUPPORT {i+1}</span>
                    </button>
                ))}
            </div>
        </div>
    );
};

interface ControlPanelProps {
  params: SimulationParams;
  paperParams: PaperParams;
  updateParams: (updates: Partial<SimulationParams>) => void;
  updatePaper: (updates: Partial<PaperParams>) => void;
  onClear: () => void;
  onRegenPaper: () => void;
  onToggleView: () => void;
  viewMode: 'ink' | 'fibers';
  activeTab: 'paint' | 'brushes' | 'physics' | 'paper' | 'studio' | 'debug';
  setActiveTab: (tab: any) => void;
  aiOperation: AIOperationState | null;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  isMinimized: boolean;
  setIsMinimized: (val: boolean) => void;
  onSaveImage: () => void;
  layoutMode: 'floating' | 'sidebar';
  setLayoutMode: (mode: 'floating' | 'sidebar') => void;
  onTraceImage: (base64: string) => void;
  onAiStudioAction: (prompt: string, type: 'think' | 'fast' | 'generate', aspectRatio?: AspectRatio) => Promise<string | undefined>;
  detectedHarmony: HarmonyAnalysis | null;
  isBusy?: boolean;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  params,
  paperParams,
  updateParams,
  updatePaper,
  onClear,
  onRegenPaper,
  onToggleView,
  viewMode,
  activeTab,
  setActiveTab,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  isMinimized,
  setIsMinimized,
  onSaveImage,
  layoutMode,
  setLayoutMode,
  onTraceImage,
  onAiStudioAction,
  detectedHarmony,
  isBusy = false
}) => {
  const [theme, setTheme] = useState<'light' | 'dark'>(() => 
    typeof document !== 'undefined' ? (document.documentElement.classList.contains('dark') ? 'dark' : 'dark') : 'dark'
  );
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [studioPrompt, setStudioPrompt] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const [selectedAspectRatio, setSelectedAspectRatio] = useState<AspectRatio>('1:1');

  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [size, setSize] = useState({ width: 420, height: window.innerHeight });
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const dragOffset = useRef({ x: 0, y: 0 });

  const toggleTheme = () => {
    const next = theme === 'light' ? 'dark' : 'light';
    setTheme(next);
    document.documentElement.classList.toggle('dark', next === 'dark');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (re) => onTraceImage(re.target?.result as string);
      reader.readAsDataURL(file);
    }
    // Reset the input value so the same file can be uploaded again if needed
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleStudioAction = async (type: 'think' | 'fast' | 'generate') => {
    if (!studioPrompt || isBusy) return;
    setAiResponse(null);
    const result = await onAiStudioAction(studioPrompt, type, selectedAspectRatio);
    if (result) setAiResponse(result);
  };

  const handleDragStart = (e: React.MouseEvent) => {
    if (layoutMode === 'sidebar') return;
    setIsDragging(true);
    dragOffset.current = { x: e.clientX - position.x, y: e.clientY - position.y };
  };

  const handleResizeStart = (e: React.MouseEvent) => { e.stopPropagation(); setIsResizing(true); };

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      if (isDragging) {
        setPosition({
          x: Math.max(0, Math.min(window.innerWidth - size.width, e.clientX - dragOffset.current.x)),
          y: Math.max(0, Math.min(window.innerHeight - 100, e.clientY - dragOffset.current.y))
        });
      }
      if (isResizing) {
        const newWidth = Math.max(340, Math.min(800, e.clientX - position.x));
        const newHeight = Math.max(400, Math.min(window.innerHeight, e.clientY - position.y));
        setSize({ width: newWidth, height: layoutMode === 'sidebar' ? window.innerHeight : newHeight });
      }
    };
    const handleUp = () => { setIsDragging(false); setIsResizing(false); };
    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMove);
      window.addEventListener('mouseup', handleUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleUp);
    };
  }, [isDragging, isResizing, position, size, layoutMode]);

  const containerStyle: React.CSSProperties = layoutMode === 'sidebar' 
    ? { width: 420, left: 0, top: 0, height: '100vh', borderRadius: 0, borderRight: '1px solid var(--border-subtle)' }
    : { width: size.width, height: size.height, left: position.x, top: position.y, borderRadius: '3rem' };

  return (
    <div 
        style={containerStyle}
        className={`fixed glass-panel z-40 flex flex-col transition-[width,left,top,opacity,transform] duration-500
          ${isMinimized ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100 scale-100 pointer-events-auto'}
          ${isDragging ? 'cursor-grabbing transition-none' : ''}
          ${isResizing ? 'transition-none' : ''}
        `}
    >
        <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />

        <div 
          onMouseDown={handleDragStart}
          className={`relative flex bg-[var(--bg-studio)]/50 pr-32 border-b border-[var(--border-subtle)] ${layoutMode === 'floating' ? 'cursor-grab rounded-t-[3rem]' : 'cursor-default'}`}
        >
          <TabButton id="paint" activeTab={activeTab} setActiveTab={setActiveTab} icon={Paintbrush} label="Paint" />
          <TabButton id="studio" activeTab={activeTab} setActiveTab={setActiveTab} icon={Brain} label="Studio" />
          <TabButton id="brushes" activeTab={activeTab} setActiveTab={setActiveTab} icon={Droplets} label="Brushes" />
          <TabButton id="physics" activeTab={activeTab} setActiveTab={setActiveTab} icon={Sliders} label="Physics" />
          <TabButton id="paper" activeTab={activeTab} setActiveTab={setActiveTab} icon={FileText} label="Paper" />
          
          <div className="absolute top-0 right-0 h-full flex items-center pr-4 gap-1">
              <button onClick={() => setLayoutMode(layoutMode === 'floating' ? 'sidebar' : 'floating')} className="w-8 h-8 flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--primary)] hover:bg-[var(--bg-card)]/60 rounded-lg transition-colors">
                {layoutMode === 'floating' ? <Columns size={16} /> : <Maximize2 size={16} />}
              </button>
              <button onClick={toggleTheme} className="w-8 h-8 flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--primary)] hover:bg-[var(--bg-card)]/60 rounded-lg transition-colors">
                {theme === 'light' ? <Moon size={16} /> : <Sun size={16} />}
              </button>
              <button onClick={() => setIsMinimized(true)} className="w-8 h-8 flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--primary)] hover:bg-[var(--bg-card)]/60 rounded-lg transition-colors">
                <ChevronDown size={18} />
              </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-8 flex flex-col gap-10">
          {activeTab === 'paint' && (
            <div className="space-y-10 animate-in fade-in slide-in-from-left-4 duration-500">
              
              {detectedHarmony && (
                  <HarmonyMatrix 
                    harmony={detectedHarmony} 
                    onSelectHue={(h) => updateParams({ color: { ...params.color, h } })} 
                  />
              )}

              <div className="grid grid-cols-3 gap-6">
                <Range label="Size" value={params.brushSize} min={1} max={40} step={0.1} onChange={(v) => updateParams({ brushSize: v })} />
                <Range label="Water" value={params.waterAmount} min={0} max={100} step={1} onChange={(v) => updateParams({ waterAmount: v })} />
                <Range label="Ink" value={params.inkAmount} min={0} max={100} step={1} onChange={(v) => updateParams({ inkAmount: v })} />
              </div>
              
              <div className="h-px bg-[var(--border-subtle)] w-full opacity-60" />
              
              <div className="space-y-8">
                <Range label="Lightness" value={params.color.l * 100} min={0} max={100} step={1} suffix="%" onChange={(v) => updateParams({ color: { ...params.color, l: v / 100 } })} />
                <Range label="Chroma" value={params.color.c} min={0} max={0.4} step={0.001} onChange={(v) => updateParams({ color: { ...params.color, c: v } })} />
                <Range label="Hue" value={params.color.h} min={0} max={360} step={1} suffix="°" onChange={(v) => updateParams({ color: { ...params.color, h: v } })} />
              </div>

              <div className="flex justify-between items-end gap-6 pt-4">
                  <div className="flex-1 space-y-6">
                    <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase tracking-[0.2em] text-[var(--text-muted)]">Presets</label>
                        <div className="flex gap-2">
                            {['LOG', 'CFG', 'DOC', 'AST'].map(fam => (
                                <button key={fam} onClick={() => updateParams({ color: COLOR.getRaw('family', fam) })} className="px-4 py-2 rounded-xl border border-[var(--border-subtle)] text-[9px] font-black hover:border-[var(--primary)] transition-colors bg-[var(--bg-studio)]">{fam}</button>
                            ))}
                        </div>
                    </div>
                    
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isBusy}
                      className={`w-full text-white py-5 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all shadow-xl
                        ${isBusy ? 'bg-[var(--text-muted)] cursor-not-allowed opacity-50 translate-y-0.5' : 'bg-[var(--primary)] hover:opacity-90 active:scale-[0.98] shadow-[var(--primary)]/20'}
                      `}
                    >
                      {isBusy ? <Loader2 size={18} className="animate-spin" /> : <ScanSearch size={18} />} 
                      {isBusy ? 'Mapping Vectors...' : 'Structural Trace'}
                    </button>
                  </div>
                  <div className="w-24 h-24 rounded-[2.5rem] shadow-2xl border-4 border-white/20 ring-8 ring-[var(--bg-studio)]/50 transition-all duration-500" style={{ backgroundColor: COLOR.toHex(params.color) }}></div>
              </div>
            </div>
          )}

          {activeTab === 'studio' && (
            <div className="space-y-10 animate-in fade-in slide-in-from-left-4 duration-500">
               <div className="space-y-4">
                  <label className="text-[11px] uppercase font-black tracking-widest text-[var(--text-muted)] flex items-center gap-2">
                     <Brain size={14} className="text-[var(--primary)]" /> Gemini Intelligence
                  </label>
                  <textarea 
                    value={studioPrompt}
                    disabled={isBusy}
                    onChange={(e) => setStudioPrompt(e.target.value)}
                    placeholder="Describe a vision to paint or ask for complex analysis..."
                    className="w-full h-32 bg-[var(--bg-studio)] border border-[var(--border-subtle)] rounded-3xl p-5 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-[var(--primary)]/30 transition-all disabled:opacity-50"
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                     <button 
                        onClick={() => handleStudioAction(isThinking ? 'think' : 'fast')}
                        disabled={isBusy}
                        className={`flex-1 bg-[var(--bg-studio)] border border-[var(--border-subtle)] text-[var(--text-main)] py-4 rounded-2xl text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-sm
                          ${isBusy ? 'opacity-50 cursor-not-allowed' : 'hover:bg-[var(--primary)] hover:text-white'}
                        `}
                     >
                        {isBusy && activeTab === 'studio' ? <Loader2 size={16} className="animate-spin" /> : (isThinking ? <Brain size={16} className="animate-pulse" /> : <Zap size={16} />)}
                        {isThinking ? 'Thinking Solve' : 'Fast Response'}
                     </button>
                     <button 
                        onClick={() => handleStudioAction('generate')}
                        disabled={isBusy}
                        className={`flex-1 text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg
                          ${isBusy ? 'bg-[var(--text-muted)] opacity-50 cursor-not-allowed' : 'bg-[var(--primary)] hover:opacity-90'}
                        `}
                     >
                        {isBusy && activeTab === 'studio' ? <Loader2 size={16} className="animate-spin" /> : <Wand2 size={16} />} Imagine & Paint
                     </button>
                  </div>

                  <div className="flex items-center gap-4 pt-2">
                    <label className={`flex items-center gap-2 cursor-pointer group ${isBusy ? 'pointer-events-none opacity-50' : ''}`}>
                        <div className="relative">
                            <input type="checkbox" checked={isThinking} onChange={() => setIsThinking(!isThinking)} disabled={isBusy} className="sr-only" />
                            <div className={`w-10 h-5 rounded-full transition-colors ${isThinking ? 'bg-[var(--primary)]' : 'bg-[var(--border-subtle)]'}`}></div>
                            <div className={`absolute left-1 top-1 w-3 h-3 bg-white rounded-full transition-transform ${isThinking ? 'translate-x-5' : ''}`}></div>
                        </div>
                        <span className="text-[9px] font-black uppercase tracking-widest text-[var(--text-muted)] group-hover:text-[var(--text-main)]">Enable High-Complexity Reasoning</span>
                    </label>
                  </div>
               </div>

               <div className="space-y-4">
                  <label className="text-[11px] uppercase font-black tracking-widest text-[var(--text-muted)]">Image Generation Aspect Ratio</label>
                  <div className="grid grid-cols-4 gap-2">
                     {['1:1', '2:3', '3:2', '3:4', '4:3', '9:16', '16:9', '21:9'].map((ratio) => (
                        <button 
                          key={ratio} 
                          disabled={isBusy}
                          onClick={() => setSelectedAspectRatio(ratio as AspectRatio)}
                          className={`py-3 text-[9px] font-black rounded-xl border transition-all ${selectedAspectRatio === ratio ? 'bg-[var(--primary-soft)] border-[var(--primary)] text-[var(--primary)]' : 'bg-[var(--bg-studio)] border-[var(--border-subtle)] text-[var(--text-muted)]'} ${isBusy ? 'opacity-50' : ''}`}
                        >
                           {ratio}
                        </button>
                     ))}
                  </div>
               </div>

               {aiResponse && (
                  <div className="bg-[var(--bg-studio)] border border-[var(--primary)]/20 rounded-3xl p-6 space-y-3 animate-in fade-in slide-in-from-bottom-2">
                     <div className="flex justify-between items-center">
                        <span className="text-[8px] font-black uppercase tracking-widest text-[var(--primary)]">Response Insight</span>
                        <Sparkles size={12} className="text-[var(--primary)] animate-pulse" />
                     </div>
                     <p className="text-xs leading-relaxed text-[var(--text-main)] whitespace-pre-wrap">{aiResponse}</p>
                     <button onClick={() => setAiResponse(null)} className="text-[9px] font-black uppercase tracking-widest text-[var(--text-muted)] hover:text-[var(--error)] transition-colors">Dismiss</button>
                  </div>
               )}
            </div>
          )}

          {activeTab === 'brushes' && (
            <div className="grid grid-cols-2 gap-6 animate-in fade-in slide-in-from-left-4 duration-500">
              {Object.values(BrushType).map((type) => (
                <button key={type} onClick={() => updateParams({ brushType: type })} className={`flex-col items-center justify-center p-6 rounded-[2rem] border-2 transition-all flex h-32 ${params.brushType === type ? 'border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary)] shadow-lg' : 'border-[var(--border-subtle)] bg-[var(--bg-card)] text-[var(--text-muted)]'}`}>
                  <span className="text-[11px] font-black uppercase tracking-widest">{type}</span>
                </button>
              ))}
            </div>
          )}

          {activeTab === 'physics' && (
            <div className="grid grid-cols-1 gap-12 animate-in fade-in slide-in-from-left-4 duration-500">
              <Range label="Drying Speed" value={params.dryingSpeed} min={0} max={100} step={1} onChange={(v) => updateParams({ dryingSpeed: v })} />
              <Range label="Viscosity" value={params.viscosity} min={0} max={100} step={1} onChange={(v) => updateParams({ viscosity: v })} />
              <Range label="Paper Resist" value={params.paperResist} min={0} max={100} step={1} onChange={(v) => updateParams({ paperResist: v })} />
              <Range label="Pigment Weight" value={params.inkWeight} min={0} max={100} step={1} onChange={(v) => updateParams({ inkWeight: v })} />
            </div>
          )}

          {activeTab === 'paper' && (
            <div className="space-y-12 animate-in fade-in slide-in-from-left-4 duration-500">
              <div className="space-y-4">
                  <label className="text-[11px] uppercase font-black tracking-widest text-[var(--text-muted)]">Surface Matrix</label>
                  <div className="flex bg-[var(--bg-studio)] p-1.5 rounded-[1.5rem] border border-[var(--border-subtle)]">
                      {Object.values(PaperType).map((type) => (
                          <button key={type} onClick={() => { updatePaper({ type }); setTimeout(onRegenPaper, 10); }} className={`flex-1 py-3 text-[10px] uppercase font-black rounded-xl transition-all ${paperParams.type === type ? 'bg-[var(--bg-card)] text-[var(--primary)] shadow-md' : 'text-[var(--text-muted)]'}`}>{type}</button>
                      ))}
                  </div>
              </div>
              <div className="space-y-4">
                  <label className="text-[11px] uppercase font-black tracking-widest text-[var(--text-muted)]">Density</label>
                  <div className="flex bg-[var(--bg-studio)] p-1.5 rounded-[1.5rem] border border-[var(--border-subtle)]">
                      {[256, 512, 1024].map((res) => (
                          <button key={res} onClick={() => updatePaper({ resolution: res as any })} className={`flex-1 py-3 text-[10px] uppercase font-black rounded-xl transition-all ${paperParams.resolution === res ? 'bg-[var(--bg-card)] text-[var(--primary)] shadow-md' : 'text-[var(--text-muted)]'}`}>{res === 256 ? 'Draft' : res === 512 ? 'Retina' : 'Studio'}</button>
                      ))}
                  </div>
              </div>
              <button onClick={onRegenPaper} className="w-full bg-[var(--text-main)] text-[var(--bg-studio)] py-6 rounded-[2rem] text-[11px] font-black uppercase tracking-[0.25em] flex items-center justify-center gap-3 hover:bg-[var(--primary)] transition-all shadow-2xl"><RefreshCw size={18} /> Regrow Texture</button>
            </div>
          )}
        </div>

        <div className="p-8 border-t border-[var(--border-subtle)] flex gap-3">
            <button onClick={onUndo} disabled={!canUndo || isBusy} className={`w-14 h-14 rounded-2xl flex items-center justify-center border transition-all ${canUndo && !isBusy ? 'bg-[var(--bg-card)] text-[var(--text-main)] hover:border-[var(--primary)]' : 'opacity-20 cursor-not-allowed'}`}><Undo2 size={20} /></button>
            <button onClick={onRedo} disabled={!canRedo || isBusy} className={`w-14 h-14 rounded-2xl flex items-center justify-center border transition-all ${canRedo && !isBusy ? 'bg-[var(--bg-card)] text-[var(--text-main)] hover:border-[var(--primary)]' : 'opacity-20 cursor-not-allowed'}`}><Redo2 size={20} /></button>
            <button onClick={onSaveImage} disabled={isBusy} className={`w-14 h-14 rounded-2xl border flex items-center justify-center bg-[var(--bg-card)] transition-all ${isBusy ? 'opacity-50 cursor-not-allowed' : 'hover:border-[var(--primary)]'}`}><ImageIcon size={20} /></button>
            <button onClick={onClear} disabled={isBusy} className={`flex-1 bg-[var(--bg-card)] border text-[var(--text-main)] rounded-2xl text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md ${isBusy ? 'opacity-50 cursor-not-allowed' : 'hover:bg-[var(--error)] hover:text-white'}`}><Trash2 size={16} /> Reset</button>
            <button onClick={onToggleView} disabled={isBusy} className={`flex-1 border rounded-2xl text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md ${isBusy ? 'opacity-50 cursor-not-allowed' : (viewMode === 'fibers' ? 'bg-[var(--primary)] text-white' : 'bg-[var(--bg-card)]')}`}><Eye size={16} /> {viewMode === 'fibers' ? 'Ink' : 'Fibers'}</button>
        </div>

        <div onMouseDown={handleResizeStart} className={`absolute bottom-0 right-0 h-full w-2 cursor-ew-resize flex items-center group`}>
            <div className="w-0.5 h-16 bg-[var(--border-strong)] rounded-full opacity-0 group-hover:opacity-40" />
        </div>
    </div>
  );
};
