
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { Mic, MicOff, Activity, Zap } from 'lucide-react';
import { LiveState } from '../types';

interface VoiceStatusProps {
  liveState: LiveState;
  toggleLive: () => void;
}

const VoiceStatus: React.FC<VoiceStatusProps> = ({ liveState, toggleLive }) => {
  const isConnected = liveState.isConnected;
  const isSpeaking = liveState.isSpeaking;

  return (
    /* 
      Invisible lateral interactive zone. 
      This container spans the full height of the viewport on the left edge.
    */
    <div className="fixed left-0 top-0 h-full w-20 z-50 group pointer-events-none flex items-center">
      
      {/* 
        The Structured Sidebar: 
        Hidden by default (opacity-0/translate-x), revealed on hover or when connected.
        Uses OKLCH-based glass effect for an "invisible" but structured feel.
      */}
      <div className={`
        pointer-events-auto h-[80vh] w-14 ml-0 flex flex-col items-center justify-between py-10
        transition-all duration-700 cubic-bezier(0.23, 1, 0.32, 1)
        rounded-r-[2rem] border-y border-r border-[var(--border-subtle)]
        bg-[oklch(var(--bg-panel-raw)_/_0.1)] backdrop-blur-[2px]
        hover:bg-[oklch(var(--bg-panel-raw)_/_0.8)] hover:backdrop-blur-xl hover:shadow-2xl hover:border-[var(--primary)]/30
        ${isConnected 
          ? 'translate-x-0 opacity-100 bg-[oklch(var(--bg-panel-raw)_/_0.85)] backdrop-blur-xl border-[var(--primary)]/40 shadow-2xl' 
          : '-translate-x-8 opacity-0 group-hover:translate-x-0 group-hover:opacity-100'
        }
      `}>
        
        {/* Top Section: Action / Trigger */}
        <div className="flex flex-col items-center gap-6">
          <div className={`p-1.5 rounded-full border border-[var(--border-subtle)] mb-2 ${isConnected ? 'animate-pulse border-[var(--primary)]/50' : ''}`}>
             <Zap size={10} className={isConnected ? 'text-[var(--primary)]' : 'text-[var(--text-muted)]'} />
          </div>
          
          <button 
            onClick={toggleLive}
            className={`w-10 h-10 rounded-full transition-all duration-500 flex items-center justify-center relative
              ${isConnected 
                ? isSpeaking 
                    ? 'bg-[var(--primary)] text-white scale-110 shadow-lg shadow-[var(--primary)]/40' 
                    : 'bg-[var(--success)] text-white shadow-lg shadow-[var(--success)]/40' 
                : 'bg-[var(--bg-studio)] text-[var(--text-muted)] hover:text-[var(--primary)] hover:bg-[var(--bg-card)]'
              }`}
          >
            {isConnected ? (
               isSpeaking ? <Activity size={18} className="animate-pulse" /> : <Mic size={18} />
            ) : (
               <MicOff size={18} className="opacity-40" />
            )}
            
            {/* Ping indicator */}
            {isConnected && (
              <span className="absolute -inset-1.5 rounded-full border-2 border-[var(--primary)]/20 animate-ping opacity-20"></span>
            )}
          </button>
        </div>

        {/* Middle Section: Structured Status (Vertical Type) */}
        <div className="flex flex-col items-center gap-4 py-8 select-none">
            <span 
              className="text-[8px] font-black uppercase tracking-[0.5em] text-[var(--text-muted)] opacity-30"
              style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}
            >
              AI ASSISTANT
            </span>
            
            <div className={`h-12 w-px transition-all duration-1000 ${isConnected ? 'bg-gradient-to-b from-[var(--primary)] to-transparent h-16' : 'bg-[var(--border-subtle)]'}`} />
            
            <span 
              className={`text-[10px] font-black uppercase tracking-[0.3em] transition-all duration-500
                ${isConnected ? 'text-[var(--text-main)]' : 'text-[var(--text-muted)] opacity-20'}
              `}
              style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}
            >
              {isConnected 
                ? (isSpeaking ? 'TRANSMITTING' : 'LISTENING') 
                : 'STANDBY'}
            </span>
        </div>

        {/* Bottom Section: Volume / Physics Indicator */}
        <div className="h-16 flex items-end pb-2">
            {isConnected && isSpeaking ? (
                <div className="flex items-end gap-1 px-2 h-10">
                    {[0.4, 0.8, 0.6, 1, 0.5].map((h, i) => (
                        <div 
                            key={i}
                            className="w-0.5 bg-[var(--primary)] rounded-full transition-all duration-150"
                            style={{ 
                                height: `${h * 100}%`,
                                opacity: 0.3 + (h * 0.7),
                                animation: 'verticalPulse 1.2s infinite ease-in-out',
                                animationDelay: `${i * 0.15}s`
                            }}
                        />
                    ))}
                </div>
            ) : (
                <div className="w-1.5 h-1.5 rounded-full bg-[var(--border-strong)] opacity-20" />
            )}
        </div>
      </div>

      {/* Slide-out Error Message (Remains outside sidebar for visibility) */}
      {liveState.error && (
        <div className="absolute left-20 top-1/2 -translate-y-1/2 bg-[var(--error)] text-white px-6 py-3 rounded-2xl text-[9px] font-black uppercase tracking-widest animate-in slide-in-from-left-4 fade-in shadow-2xl border border-white/10">
          {liveState.error}
        </div>
      )}

      <style>{`
        @keyframes verticalPulse {
          0%, 100% { transform: scaleY(1); }
          50% { transform: scaleY(1.8); }
        }
      `}</style>
    </div>
  );
};

export default VoiceStatus;
