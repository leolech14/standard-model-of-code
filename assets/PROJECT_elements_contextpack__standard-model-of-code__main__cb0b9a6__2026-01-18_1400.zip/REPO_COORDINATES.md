# REPO_COORDINATES.md
## Context Pack v2 Handshake

**Generated**: 2026-01-18 13:54 UTC
**Pack Version**: 2.0

---

## Working Directory
```
/Users/lech/PROJECTS_all/PROJECT_elements/standard-model-of-code
```

## Git Status
```
On branch main
Commit: cb0b9a6 Fix: FILE mode and FLOW mode critical bugs

Status: DIRTY (modifications + untracked + deletions)

Tracked Remote: origin → https://github.com/leolech14/standard-model-of-code.git
Branch diverged from origin/pr/all-updates (65 local vs 23 remote commits)
```

### Modified Files (17)
```
 M CLAUDE.md
 M ROADMAP.md
 M docs/ORIENTATION_FILES.md
 M docs/theory/THEORY.md
 M requirements.txt
 M schema/viz/tokens/appearance.tokens.json
 M schema/viz/tokens/controls.tokens.json
 M scripts/sync-orientation-files.sh
 M src/core/full_analysis.py
 M src/core/normalize_output.py
 M src/core/tree_sitter_engine.py
 M src/core/unified_analysis.py
 M src/core/universal_detector.py
 M src/core/viz/appearance_engine.py
 M src/core/viz/controls_engine.py
 M tests/test_contract_output.py
 M tools/visualize_graph_webgl.py
```

### Deleted Files (4)
```
 D src/core/dependency_analyzer.py
 D src/core/particle_classifier.py
 D src/core/viz_generator.py
 D tools/visualize_graph.py
```

### Untracked Files (14)
```
?? .collider/
?? MANIFEST.in
?? collider_output/
?? docs/DATA_LAYER_REFACTORING_MAP.md
?? experiments/analogy_mapper.py
?? scripts/analyze_latest_activity.py
?? scripts/generate_repo_timestamps.py
?? src/core/viz/__init__.py
?? src/core/viz/assets/app.js.backup
?? src/core/viz/assets/cmd-btn.css
?? src/core/viz/assets/vendor/
?? src/core/viz/physics_engine.py
?? src/core/viz/token_resolver.py
?? tools/verify_animation.py
```

## Local Branches
```
* main                              cb0b9a6
  pr/all-updates                    cccd45f
  pr/ci-fix                         dc7cc41
  pr/entrypoint-expansion           26892fd
  pr/phase2-resolution              82750e5
  pr/purpose-emergence-fix          c62f71c
  pr/testinfra                      8b02469
  repair/audit-failures-antigravity 24967b6
```

## Remote Configuration
```
origin  https://github.com/leolech14/standard-model-of-code.git (fetch)
origin  https://github.com/leolech14/standard-model-of-code.git (push)
```

## Environment Versions
```
Python 3.14.0
Node v25.2.1
```

## Project Tree (3 levels)
```
standard-model-of-code/
├── cli.py                    # Main CLI entrypoint
├── CLAUDE.md                 # Agent instructions
├── README.md                 # Project overview
├── ROADMAP.md                # Development roadmap
├── MANIFEST.in               # Python package manifest (NEW)
├── requirements.txt          # Python dependencies
├── pyproject.toml            # Project config
├── docs/
│   ├── theory/
│   │   └── THEORY.md         # Core theory document
│   ├── roadmaps/
│   │   ├── C1_ATOM_ENUMERATION.md
│   │   ├── C2_JSON_SCHEMA.md
│   │   └── C3_TRAINING_CORPUS.md
│   ├── prompts/              # Validation prompts
│   ├── TOOL.md               # Tool documentation
│   ├── STORAGE_ARCHITECTURE.md
│   ├── ORIENTATION_FILES.md
│   └── DATA_LAYER_REFACTORING_MAP.md  # NEW - drift analysis
├── schema/
│   ├── fixed/
│   │   ├── atoms.json        # 185 atoms
│   │   ├── dimensions.json   # 8 dimensions
│   │   └── roles.json        # 33 roles
│   ├── crosswalks/           # AST→Atom mappings (5 languages)
│   ├── particle.schema.json  # Particle JSON Schema
│   ├── graph.schema.json     # Graph JSON Schema
│   ├── types.py              # Python types
│   └── types.ts              # TypeScript types
├── src/
│   └── core/
│       ├── full_analysis.py  # Main pipeline
│       ├── atom_registry.py  # Runtime atoms (117)
│       ├── viz/              # Visualization engine
│       └── ...
├── tests/
│   ├── fixtures/             # Test data
│   └── test_*.py
└── tools/                    # Utility scripts
```

## Key Project Facts

| Aspect | Value |
|--------|-------|
| Project | Standard Model of Code + Collider |
| Theory | ~200 atoms, 8 dimensions, 33 roles, 5 edge families |
| Tool | Collider - static analysis producing JSON+HTML |
| Primary Language | Python (CLI + analysis) |
| Viz Language | JavaScript (WebGL) |
| Schema Format | JSON Schema 2020-12 |
| Status | Active development, dirty repo |

## v2 Additions

This pack includes:
- `WORKTREE_DIFF.patch` — Full diff of uncommitted changes
- `WORKTREE_STATUS.txt` — git status --porcelain=v1
- `REMOTE_REFS.txt` — All local branch refs
- `REMOTES.txt` — Remote configuration
- `docs/DATA_LAYER_REFACTORING_MAP.md` — Drift analysis document
- `MANIFEST.in` — Python package manifest

---

*This file was generated automatically for Context Pack v2.*
