#!/bin/bash
# Backward compatibility wrapper
# Redirects to the versioned script inside the repo.
# This file lives OUTSIDE the repo and is NOT committed.

exec "/Users/lech/PROJECTS_all/PROJECT_elements/standard-model-of-code/scripts/sync-orientation-files.sh" "$@"
