from pkg.b import helper

def main():
    return helper()
