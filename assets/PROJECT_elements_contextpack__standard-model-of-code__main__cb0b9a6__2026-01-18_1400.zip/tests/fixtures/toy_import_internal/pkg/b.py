def helper():
    return 42
