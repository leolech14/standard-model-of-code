import json  # extra import must not affect proof

def helper():
    return 1

def main():
    return helper()

if __name__ == "__main__":
    main()
