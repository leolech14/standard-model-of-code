# Local module named json - creates ambiguity with stdlib
def dumps(data):
    return str(data)
