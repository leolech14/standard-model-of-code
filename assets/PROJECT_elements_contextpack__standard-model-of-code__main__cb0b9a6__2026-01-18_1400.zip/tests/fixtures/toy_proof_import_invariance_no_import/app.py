def helper():
    return 1

def main():
    return helper()

if __name__ == "__main__":
    main()
