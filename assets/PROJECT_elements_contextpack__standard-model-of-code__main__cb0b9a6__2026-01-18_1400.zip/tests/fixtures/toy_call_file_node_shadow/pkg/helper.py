# constants-only module (no functions/classes)
X = 1
