"""
Token resolver for design tokens.

Resolves design tokens from JSON files in schema/viz/tokens/.
Provides lookup with dot-notation paths and default fallbacks.
"""

import json
from pathlib import Path
from typing import Any, Optional

# Singleton instance
_resolver_instance = None


class TokenResolver:
    """Resolves design tokens from JSON schema files."""

    def __init__(self, tokens_dir: Optional[Path] = None):
        """
        Initialize the token resolver.

        Args:
            tokens_dir: Path to tokens directory. Defaults to schema/viz/tokens/.
        """
        if tokens_dir is None:
            # Find the project root by going up from this file
            current = Path(__file__).resolve()
            project_root = current.parent.parent.parent.parent
            tokens_dir = project_root / "schema" / "viz" / "tokens"

        self.tokens_dir = Path(tokens_dir)
        self._appearance_tokens = self._load_tokens("appearance.tokens.json")
        self._controls_tokens = self._load_tokens("controls.tokens.json")

    def _load_tokens(self, filename: str) -> dict:
        """Load tokens from a JSON file."""
        filepath = self.tokens_dir / filename
        if filepath.exists():
            try:
                with open(filepath, "r") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return {}
        return {}

    def _resolve_path(self, tokens: dict, path: str) -> Any:
        """
        Resolve a dot-notation path in the tokens dict.

        Handles both direct values and $value wrapped values.

        Args:
            tokens: Token dictionary to search
            path: Dot-notation path like "color.edge.default"

        Returns:
            The resolved value or None if not found
        """
        parts = path.split(".")
        current = tokens

        for part in parts:
            if not isinstance(current, dict):
                return None
            if part not in current:
                return None
            current = current[part]

        # If we found a dict with $value, extract it
        if isinstance(current, dict) and "$value" in current:
            return current["$value"]

        return current

    def appearance(self, path: str, default: Any = None) -> Any:
        """
        Get an appearance token value.

        Args:
            path: Dot-notation path like "color.edge.default"
            default: Default value if path not found

        Returns:
            The token value or default
        """
        result = self._resolve_path(self._appearance_tokens, path)
        return result if result is not None else default

    def controls(self, path: str, default: Any = None) -> Any:
        """
        Get a controls token value.

        Args:
            path: Dot-notation path like "panels.metrics.visible"
            default: Default value if path not found

        Returns:
            The token value or default
        """
        result = self._resolve_path(self._controls_tokens, path)
        return result if result is not None else default


def get_resolver() -> TokenResolver:
    """
    Get the singleton token resolver instance.

    Returns:
        TokenResolver instance
    """
    global _resolver_instance
    if _resolver_instance is None:
        _resolver_instance = TokenResolver()
    return _resolver_instance
