# 🚀 SPECTROMETER V12 MINIMAL - Core Module
# Universal pattern detection core