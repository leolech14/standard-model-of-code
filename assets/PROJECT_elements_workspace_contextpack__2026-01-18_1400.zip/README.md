# PROJECT_elements

> **The effort to find the basic constituents of computer programs.**

---

## The Dichotomy

| | Theory | Practice |
|---|--------|----------|
| **Name** | Standard Model of Code | Collider |
| **Purpose** | The map | The tool that uses the map |
| **Question** | *What are the atoms of software?* | *How do we detect them?* |
| **Location** | `docs/`, `schema/` | `src/core/`, `cli.py` |

This is the most distinctive aspect of PROJECT_elements: **theory and application live together, informing each other**.

---

## The Model

A **theoretical framework** — a map — that aims to consolidate, in a **topological continuum**, all basic components of the software engineering space.

This is an **open model**: always growing and reframing its assumptions.

---

## The Codespace

We call this hyper-complex, high-dimensional space the **codespace** — where all software artifacts exist and relate.

### Canonical Order (Roots → Leaves)

| Level | Concept | Status |
|-------|---------|--------|
| **0** | **Three Parallel Layers** (Physical, Virtual, Semantic) | 🟢 Always Green |
| **1** | **16-Level Scale** (Bit → Universe) | Backbone |
| **2** | Atoms, Dimensions, Roles | Active |
| **3** | Patterns, Violations, Predictions | Active |

---

## Quick Start

```bash
cd standard-model-of-code
./collider full /path/to/repo
```

👉 **[Enter the project](standard-model-of-code/README.md)**
